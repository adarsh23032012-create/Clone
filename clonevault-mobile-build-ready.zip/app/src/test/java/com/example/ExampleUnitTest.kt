package com.example

import com.example.engine.ApkClonerEngine
import com.example.engine.ApkSignerV2
import com.example.engine.AxmlPackagePatcher
import com.example.weather.WeatherCondition
import com.example.weather.WeatherViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.security.cert.CertificateFactory
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

class ExampleUnitTest {

    @Test
    fun `axml patcher renames utf8 package string cleanly`() {
        val originalPkg = "com.example.original"
        val clonedPkg = "com.vaultbox.s1.original"
        val axml = buildMinimalUtf8Axml(
            listOf("manifest", originalPkg, "$originalPkg.provider", "android.intent.category.LAUNCHER")
        )

        val result = AxmlPackagePatcher.patchManifestPackage(
            axmlBytes = axml,
            originalPackage = originalPkg,
            clonedPackage = clonedPkg,
            hideFromLauncher = true
        )
        assertEquals(2, result.stringsReplacedCount)
        assertTrue(result.launcherHidden)

        val buf = ByteBuffer.wrap(result.patchedBytes).order(ByteOrder.LITTLE_ENDIAN)
        assertEquals(0x0003, buf.getShort(0).toInt() and 0xFFFF)
        assertEquals(result.patchedBytes.size, buf.getInt(4))

        val roundTrip = AxmlPackagePatcher.patchManifestPackage(
            axmlBytes = result.patchedBytes,
            originalPackage = clonedPkg,
            clonedPackage = originalPkg,
            hideFromLauncher = false
        )
        assertEquals(2, roundTrip.stringsReplacedCount)
    }

    @Test
    fun `apk signer v2 generates valid x509 cert and embeds signing block`() {
        val tempDir = Files.createTempDirectory("vaultbox_signer_test").toFile()
        try {
            val identity = ApkSignerV2.getOrCreateIdentity(tempDir.resolve("ks"))
            val cert = CertificateFactory.getInstance("X.509")
                .generateCertificate(identity.certificateDer.inputStream())
            assertTrue(cert.publicKey != null)

            val unsignedApk = tempDir.resolve("unsigned.apk")
            val signedApk = tempDir.resolve("signed.apk")
            ZipOutputStream(FileOutputStream(unsignedApk)).use { zos ->
                zos.putNextEntry(ZipEntry("AndroidManifest.xml"))
                zos.write("manifest-payload".toByteArray())
                zos.closeEntry()
            }

            val sha = ApkSignerV2.signApkV2(unsignedApk, signedApk, identity)
            assertEquals(64, sha.length)
            assertTrue(signedApk.length() > unsignedApk.length())

            ZipFile(signedApk).use { zip ->
                assertTrue(zip.getEntry("AndroidManifest.xml") != null)
            }
        } finally {
            tempDir.deleteRecursively()
        }
    }

    @Test
    fun `cloned package name generator produces valid android package id`() {
        val generated = ApkClonerEngine.generateClonedPackageName("com.whatsapp", "Box-2")
        assertEquals("com.vaultbox.box2.whatsapp", generated)
    }

    @Test
    fun `promo code unlocks cloner only for iuyu`() {
        assertTrue(WeatherViewModel.isPromoCodeValid("iuyu"))
        assertTrue(WeatherViewModel.isPromoCodeValid(" iuyu "))
        assertFalse(WeatherViewModel.isPromoCodeValid("IUYU"))
        assertFalse(WeatherViewModel.isPromoCodeValid("wrong"))
        assertFalse(WeatherViewModel.isPromoCodeValid(""))
    }

    @Test
    fun `weather condition maps wmo codes and formats temperature`() {
        assertEquals(WeatherCondition.CLEAR, WeatherCondition.fromWmoCode(0))
        assertEquals(WeatherCondition.RAIN, WeatherCondition.fromWmoCode(63))
        assertEquals(WeatherCondition.THUNDERSTORM, WeatherCondition.fromWmoCode(95))
        assertEquals("68°", WeatherViewModel.formatTemp(20.0, fahrenheit = true))
        assertEquals("20°", WeatherViewModel.formatTemp(20.0, fahrenheit = false))
    }

    private fun buildMinimalUtf8Axml(strings: List<String>): ByteArray {
        val stringData = ByteArrayOutputStream()
        val offsets = IntArray(strings.size)
        strings.forEachIndexed { idx, s ->
            offsets[idx] = stringData.size()
            val utf8 = s.toByteArray(StandardCharsets.UTF_8)
            stringData.write(s.length)
            stringData.write(utf8.size)
            stringData.write(utf8)
            stringData.write(0)
        }
        while (stringData.size() % 4 != 0) stringData.write(0)
        val stringsBytes = stringData.toByteArray()

        val poolHeaderSize = 28
        val stringsStart = poolHeaderSize + strings.size * 4
        val poolSize = stringsStart + stringsBytes.size
        val fakeTail = ByteArray(16)
        val totalSize = 8 + poolSize + fakeTail.size

        val buf = ByteBuffer.allocate(totalSize).order(ByteOrder.LITTLE_ENDIAN)
        buf.putShort(0x0003)
        buf.putShort(8)
        buf.putInt(totalSize)

        buf.putShort(0x0001)
        buf.putShort(poolHeaderSize.toShort())
        buf.putInt(poolSize)
        buf.putInt(strings.size)
        buf.putInt(0)
        buf.putInt(1 shl 8)
        buf.putInt(stringsStart)
        buf.putInt(0)
        offsets.forEach { buf.putInt(it) }
        buf.put(stringsBytes)
        buf.put(fakeTail)
        return buf.array()
    }
}
