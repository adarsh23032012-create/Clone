package com.example.data

import kotlinx.coroutines.flow.Flow
import java.io.File

class VaultRepository(private val dao: VaultDao) {

    val allClones: Flow<List<ClonedAppEntity>> = dao.observeAllClones()
    val recentEvents: Flow<List<SandboxEventEntity>> = dao.observeRecentEvents()

    fun observeClone(id: Long): Flow<ClonedAppEntity?> = dao.observeCloneById(id)

    fun observeEventsForClone(cloneId: Long): Flow<List<SandboxEventEntity>> =
        dao.observeEventsForClone(cloneId)

    suspend fun saveClone(clone: ClonedAppEntity, initialEventDetail: String): Long {
        val insertedId = dao.insertClone(clone)
        dao.insertEvent(
            SandboxEventEntity(
                cloneId = insertedId,
                appTitle = clone.cloneLabel,
                eventType = "CLONE_CREATED",
                detail = initialEventDetail
            )
        )
        return insertedId
    }

    suspend fun updateClone(clone: ClonedAppEntity) {
        dao.updateClone(clone)
    }

    suspend fun logEvent(cloneId: Long, appTitle: String, eventType: String, detail: String) {
        dao.insertEvent(
            SandboxEventEntity(
                cloneId = cloneId,
                appTitle = appTitle,
                eventType = eventType,
                detail = detail
            )
        )
    }

    suspend fun deleteCloneAndFiles(clone: ClonedAppEntity) {
        runCatching {
            val snapshotFile = File(clone.originalSnapshotPath)
            snapshotFile.parentFile?.deleteRecursively()
        }
        runCatching {
            val dataDir = File(clone.isolatedDataDir)
            if (dataDir.exists()) dataDir.deleteRecursively()
        }
        dao.deleteEventsForClone(clone.id)
        dao.deleteCloneById(clone.id)
    }
}
