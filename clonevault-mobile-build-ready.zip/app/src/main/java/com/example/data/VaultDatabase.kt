package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters

class VaultTypeConverters {
    @TypeConverter
    fun fromIsolationMode(mode: IsolationMode): String = mode.name

    @TypeConverter
    fun toIsolationMode(value: String): IsolationMode =
        runCatching { IsolationMode.valueOf(value) }.getOrDefault(IsolationMode.STANDALONE_CLONE)

    @TypeConverter
    fun fromNetworkMode(mode: NetworkIsolationMode): String = mode.name

    @TypeConverter
    fun toNetworkMode(value: String): NetworkIsolationMode =
        runCatching { NetworkIsolationMode.valueOf(value) }.getOrDefault(NetworkIsolationMode.TRACKER_FILTER)
}

@Database(
    entities = [ClonedAppEntity::class, SandboxEventEntity::class],
    version = 2,
    exportSchema = false
)
@TypeConverters(VaultTypeConverters::class)
abstract class VaultDatabase : RoomDatabase() {
    abstract fun vaultDao(): VaultDao

    companion object {
        @Volatile
        private var INSTANCE: VaultDatabase? = null

        fun getInstance(context: Context): VaultDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    VaultDatabase::class.java,
                    "vaultbox_sandbox.db"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
