package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface VaultDao {
    @Query("SELECT * FROM cloned_apps ORDER BY createdAt DESC")
    fun observeAllClones(): Flow<List<ClonedAppEntity>>

    @Query("SELECT * FROM cloned_apps WHERE id = :id")
    fun observeCloneById(id: Long): Flow<ClonedAppEntity?>

    @Query("SELECT * FROM cloned_apps WHERE id = :id")
    suspend fun getCloneById(id: Long): ClonedAppEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClone(clone: ClonedAppEntity): Long

    @Update
    suspend fun updateClone(clone: ClonedAppEntity)

    @Query("DELETE FROM cloned_apps WHERE id = :id")
    suspend fun deleteCloneById(id: Long)

    @Query("SELECT * FROM sandbox_events ORDER BY timestamp DESC LIMIT 100")
    fun observeRecentEvents(): Flow<List<SandboxEventEntity>>

    @Query("SELECT * FROM sandbox_events WHERE cloneId = :cloneId ORDER BY timestamp DESC")
    fun observeEventsForClone(cloneId: Long): Flow<List<SandboxEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: SandboxEventEntity)

    @Query("DELETE FROM sandbox_events WHERE cloneId = :cloneId")
    suspend fun deleteEventsForClone(cloneId: Long)
}
