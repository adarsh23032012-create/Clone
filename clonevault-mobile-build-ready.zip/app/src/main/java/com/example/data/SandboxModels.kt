package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class IsolationMode(
    val displayName: String,
    val shortTag: String,
    val description: String
) {
    STANDALONE_CLONE(
        displayName = "Standalone Package Clone",
        shortTag = "PACKAGE CLONE",
        description = "Re-identifies AndroidManifest package ID and builds an independent signed clone APK that continues working even after the main app is uninstalled."
    ),
    WORK_PROFILE(
        displayName = "Managed Sandbox Profile",
        shortTag = "WORK PROFILE",
        description = "Isolates the cloned app inside Android's separate OS user profile completely separated from your personal apps."
    ),
    VAULT_SNAPSHOT(
        displayName = "Isolated Vault Archive",
        shortTag = "VAULT SNAPSHOT",
        description = "Preserves the full APK snapshot, isolated data directory, and sandbox rules inside VaultBox independently of the main app."
    )
}

enum class NetworkIsolationMode(val label: String) {
    DIRECT("Direct"),
    TRACKER_FILTER("Tracker Shield"),
    OFFLINE("Offline Sandbox")
}

@Entity(tableName = "cloned_apps")
data class ClonedAppEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cloneUuid: String,
    val displayName: String,
    val cloneLabel: String,
    val originalPackageName: String,
    val clonedPackageName: String,
    val versionName: String,
    val versionCode: Long,
    val minSdk: Int,
    val targetSdk: Int,
    val apkSizeBytes: Long,
    val originalSnapshotPath: String,
    val clonedApkPath: String,
    val isolatedDataDir: String,
    val signingSha256: String,
    val cloneSigningSha256: String,
    val dexCount: Int,
    val nativeAbis: String,
    val permissionsList: String,
    val isolationMode: IsolationMode,
    val isolateStorage: Boolean = true,
    val isolateDeviceIds: Boolean = true,
    val blockTrackers: Boolean = true,
    val networkMode: NetworkIsolationMode = NetworkIsolationMode.TRACKER_FILTER,
    val hideFromLauncher: Boolean = true,
    val mainActivityClass: String = "",
    val manifestPatched: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val lastVerifiedAt: Long = System.currentTimeMillis(),
    val notes: String = ""
)

@Entity(tableName = "sandbox_events")
data class SandboxEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cloneId: Long,
    val appTitle: String,
    val eventType: String,
    val detail: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class ClonedAppStatus(
    val entity: ClonedAppEntity,
    val isMainAppInstalledOutside: Boolean,
    val isClonePackageInstalled: Boolean,
    val isActiveInManagedProfile: Boolean,
    val snapshotFileExists: Boolean,
    val clonedApkFileExists: Boolean,
    val isolatedDataSizeBytes: Long
) {
    val survivesMainUninstall: Boolean
        get() = snapshotFileExists || isClonePackageInstalled || isActiveInManagedProfile

    val isRunnableIndependently: Boolean
        get() = isClonePackageInstalled || isActiveInManagedProfile
}
