package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.ClonedAppEntity
import com.example.ui.LaunchAttemptResult
import com.example.ui.SandboxViewModel
import com.example.ui.screens.CloneDetailScreen
import com.example.ui.screens.CloneLabScreen
import com.example.ui.screens.IsolationProfilesScreen
import com.example.ui.screens.VaultScreen
import com.example.ui.screens.WeatherForecastScreen
import com.example.ui.theme.VaultBoxTheme
import com.example.weather.WeatherViewModel

const val ROUTE_VAULT = "vault"
const val ROUTE_CLONE_LAB = "clone_lab"
const val ROUTE_ISOLATION = "isolation"
const val ROUTE_CLONE_DETAIL = "clone_detail/{cloneId}"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VaultBoxTheme {
                WeatherEntryGate()
            }
        }
    }
}

@Composable
fun WeatherEntryGate(
    weatherViewModel: WeatherViewModel = viewModel(),
    sandboxViewModel: SandboxViewModel = viewModel()
) {
    val isVaultUnlocked by weatherViewModel.isVaultUnlocked.collectAsStateWithLifecycle()

    if (!isVaultUnlocked) {
        val uiState by weatherViewModel.weatherUiState.collectAsStateWithLifecycle()
        val selectedLocation by weatherViewModel.selectedLocation.collectAsStateWithLifecycle()
        val useFahrenheit by weatherViewModel.useFahrenheit.collectAsStateWithLifecycle()
        val cityResults by weatherViewModel.cityResults.collectAsStateWithLifecycle()

        WeatherForecastScreen(
            uiState = uiState,
            selectedLocation = selectedLocation,
            useFahrenheit = useFahrenheit,
            cityResults = cityResults,
            onRefresh = weatherViewModel::refreshWeather,
            onToggleFahrenheit = weatherViewModel::setUseFahrenheit,
            onSearchCities = weatherViewModel::searchCities,
            onSelectLocation = weatherViewModel::selectLocation,
            onPromoCodeSubmit = weatherViewModel::applyPromoCode
        )
    } else {
        VaultBoxApp(
            viewModel = sandboxViewModel,
            onLockToWeather = weatherViewModel::lockToWeather
        )
    }
}

@Composable
fun VaultBoxApp(
    viewModel: SandboxViewModel = viewModel(),
    onLockToWeather: () -> Unit = {}
) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val allClones by viewModel.allCloneStatuses.collectAsStateWithLifecycle()
    val filteredClones by viewModel.filteredCloneStatuses.collectAsStateWithLifecycle()
    val selectedFilter by viewModel.selectedFilter.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val installedAppsState by viewModel.installedAppsState.collectAsStateWithLifecycle()
    val inspectedApk by viewModel.inspectedApk.collectAsStateWithLifecycle()
    val isInspecting by viewModel.isInspecting.collectAsStateWithLifecycle()
    val cloneBuildState by viewModel.cloneBuildState.collectAsStateWithLifecycle()
    val managedProfileState by viewModel.managedProfileState.collectAsStateWithLifecycle()
    val recentEvents by viewModel.recentEvents.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    var pendingExportEntity by remember { mutableStateOf<ClonedAppEntity?>(null) }
    var pendingDeployDialogEntity by remember { mutableStateOf<ClonedAppEntity?>(null) }

    // Re-check outside vs. inside package presence every time app returns to foreground
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        viewModel.refreshLiveStatuses()
    }

    LaunchedEffect(statusMessage) {
        statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    // Zero-permission Storage Access Framework APK importer
    val openApkLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            navController.navigate(ROUTE_CLONE_LAB) {
                launchSingleTop = true
            }
            viewModel.inspectImportedApkUri(uri)
        }
    }

    // Zero-permission Storage Access Framework APK exporter
    val exportApkLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.android.package-archive")
    ) { uri ->
        val entity = pendingExportEntity
        pendingExportEntity = null
        if (uri != null && entity != null) {
            viewModel.exportClonedApkToUri(entity, uri)
        }
    }

    val startApkExport: (ClonedAppEntity) -> Unit = { entity ->
        pendingExportEntity = entity
        val safeName = "${entity.clonedPackageName}_v${entity.versionName}.apk"
        exportApkLauncher.launch(safeName)
    }

    val startApkShare: (ClonedAppEntity) -> Unit = { entity ->
        val shareUri = viewModel.getShareableApkUri(entity)
        if (shareUri != null) {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.android.package-archive"
                putExtra(Intent.EXTRA_STREAM, shareUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(sendIntent, "Open or Share Cloned APK"))
        } else {
            viewModel.postStatusMessage("Cloned APK artifact missing from vault.")
        }
    }

    val attemptLaunchClone: (ClonedAppEntity) -> Unit = { entity ->
        when (val result = viewModel.attemptLaunchClone(entity)) {
            is LaunchAttemptResult.ReadyIntent -> {
                runCatching {
                    context.startActivity(result.intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }.onFailure {
                    viewModel.postStatusMessage("Unable to launch ${entity.clonedPackageName}.")
                }
            }
            LaunchAttemptResult.LaunchedInWorkProfile -> {
                viewModel.postStatusMessage("Launched ${entity.cloneLabel} inside Isolated Profile.")
            }
            is LaunchAttemptResult.NeedsInstallExport -> {
                pendingDeployDialogEntity = entity
            }
        }
    }

    val showTopLevelChrome = currentRoute in setOf(ROUTE_VAULT, ROUTE_CLONE_LAB, ROUTE_ISOLATION)

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 600.dp

        val navigateTopLevel: (String) -> Unit = { route ->
            navController.navigate(route) {
                popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                }
                launchSingleTop = true
                restoreState = true
            }
        }

        Row(modifier = Modifier.fillMaxSize()) {
            if (useNavRail && showTopLevelChrome) {
                NavigationRail(
                    modifier = Modifier
                        .fillMaxHeight()
                        .statusBarsPadding()
                        .navigationBarsPadding(),
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    NavigationRailItem(
                        selected = currentRoute == ROUTE_VAULT,
                        onClick = { navigateTopLevel(ROUTE_VAULT) },
                        icon = {
                            Icon(
                                imageVector = if (currentRoute == ROUTE_VAULT) Icons.Filled.Shield else Icons.Outlined.Shield,
                                contentDescription = null
                            )
                        },
                        label = { Text(stringResource(R.string.nav_vault)) },
                        modifier = Modifier.testTag("nav_rail_vault")
                    )
                    NavigationRailItem(
                        selected = currentRoute == ROUTE_CLONE_LAB,
                        onClick = { navigateTopLevel(ROUTE_CLONE_LAB) },
                        icon = {
                            Icon(
                                imageVector = if (currentRoute == ROUTE_CLONE_LAB) Icons.Filled.Build else Icons.Outlined.Build,
                                contentDescription = null
                            )
                        },
                        label = { Text(stringResource(R.string.nav_clone_lab)) },
                        modifier = Modifier.testTag("nav_rail_clone_lab")
                    )
                    NavigationRailItem(
                        selected = currentRoute == ROUTE_ISOLATION,
                        onClick = { navigateTopLevel(ROUTE_ISOLATION) },
                        icon = {
                            Icon(
                                imageVector = if (currentRoute == ROUTE_ISOLATION) Icons.Filled.Layers else Icons.Outlined.Layers,
                                contentDescription = null
                            )
                        },
                        label = { Text(stringResource(R.string.nav_isolation)) },
                        modifier = Modifier.testTag("nav_rail_isolation")
                    )
                }
            }

            Scaffold(
                modifier = Modifier.weight(1f),
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                floatingActionButton = {
                    if (currentRoute == ROUTE_VAULT) {
                        ExtendedFloatingActionButton(
                            onClick = { navigateTopLevel(ROUTE_CLONE_LAB) },
                            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                            text = { Text("Clone APK") },
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.testTag("fab_new_clone")
                        )
                    }
                },
                bottomBar = {
                    if (!useNavRail && showTopLevelChrome) {
                        NavigationBar(
                            modifier = Modifier.navigationBarsPadding(),
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            NavigationBarItem(
                                selected = currentRoute == ROUTE_VAULT,
                                onClick = { navigateTopLevel(ROUTE_VAULT) },
                                icon = {
                                    Icon(
                                        imageVector = if (currentRoute == ROUTE_VAULT) Icons.Filled.Shield else Icons.Outlined.Shield,
                                        contentDescription = null
                                    )
                                },
                                label = { Text(stringResource(R.string.nav_vault)) },
                                modifier = Modifier.testTag("nav_vault")
                            )
                            NavigationBarItem(
                                selected = currentRoute == ROUTE_CLONE_LAB,
                                onClick = { navigateTopLevel(ROUTE_CLONE_LAB) },
                                icon = {
                                    Icon(
                                        imageVector = if (currentRoute == ROUTE_CLONE_LAB) Icons.Filled.Build else Icons.Outlined.Build,
                                        contentDescription = null
                                    )
                                },
                                label = { Text(stringResource(R.string.nav_clone_lab)) },
                                modifier = Modifier.testTag("nav_clone_lab")
                            )
                            NavigationBarItem(
                                selected = currentRoute == ROUTE_ISOLATION,
                                onClick = { navigateTopLevel(ROUTE_ISOLATION) },
                                icon = {
                                    Icon(
                                        imageVector = if (currentRoute == ROUTE_ISOLATION) Icons.Filled.Layers else Icons.Outlined.Layers,
                                        contentDescription = null
                                    )
                                },
                                label = { Text(stringResource(R.string.nav_isolation)) },
                                modifier = Modifier.testTag("nav_isolation")
                            )
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .then(if (showTopLevelChrome) Modifier.statusBarsPadding() else Modifier),
                    contentAlignment = Alignment.TopCenter
                ) {
                    NavHost(
                        navController = navController,
                        startDestination = ROUTE_VAULT,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        composable(ROUTE_VAULT) {
                            VaultScreen(
                                allClones = allClones,
                                filteredClones = filteredClones,
                                selectedFilter = selectedFilter,
                                onFilterSelected = viewModel::setFilter,
                                onRefreshStatuses = viewModel::refreshLiveStatuses,
                                onOpenCloneLab = { navigateTopLevel(ROUTE_CLONE_LAB) },
                                onImportApkClick = {
                                    openApkLauncher.launch(
                                        arrayOf("application/vnd.android.package-archive", "*/*")
                                    )
                                },
                                onLearnArchitecture = { navigateTopLevel(ROUTE_ISOLATION) },
                                onOpenCloneDetails = { id ->
                                    navController.navigate("clone_detail/$id")
                                },
                                onLaunchClone = attemptLaunchClone,
                                onExportClone = startApkExport,
                                onLockToWeather = onLockToWeather,
                                loadAppIcon = viewModel::loadAppIcon
                            )
                        }

                        composable(ROUTE_CLONE_LAB) {
                            CloneLabScreen(
                                installedAppsState = installedAppsState,
                                searchQuery = searchQuery,
                                inspectedApk = inspectedApk,
                                isInspecting = isInspecting,
                                cloneBuildState = cloneBuildState,
                                onSearchQueryChange = viewModel::setSearchQuery,
                                onReloadApps = viewModel::loadInstalledApps,
                                onImportApkClick = {
                                    openApkLauncher.launch(
                                        arrayOf("application/vnd.android.package-archive", "*/*")
                                    )
                                },
                                onInspectInstalledApp = viewModel::inspectInstalledApp,
                                onDismissInspector = viewModel::clearInspectedApk,
                                onStartCloneBuild = viewModel::startCloneBuild,
                                onResetBuildState = viewModel::resetCloneBuildState,
                                onNavigateToCloneDetail = { id ->
                                    navController.navigate("clone_detail/$id")
                                },
                                loadAppIcon = viewModel::loadAppIcon
                            )
                        }

                        composable(ROUTE_ISOLATION) {
                            IsolationProfilesScreen(
                                managedProfileState = managedProfileState,
                                recentEvents = recentEvents,
                                onProvisionWorkProfile = {
                                    runCatching {
                                        context.startActivity(viewModel.buildProvisionWorkProfileIntent())
                                    }.onFailure {
                                        viewModel.postStatusMessage(
                                            "Managed Profile provisioning is not supported by this device policy."
                                        )
                                    }
                                }
                            )
                        }

                        composable(
                            route = ROUTE_CLONE_DETAIL,
                            arguments = listOf(navArgument("cloneId") { type = NavType.LongType })
                        ) { entry ->
                            val cloneId = entry.arguments?.getLong("cloneId") ?: -1L
                            val cloneStatus by viewModel.observeCloneStatus(cloneId)
                                .collectAsStateWithLifecycle()
                            val cloneEvents by viewModel.observeEventsForClone(cloneId)
                                .collectAsStateWithLifecycle()
                            val initialNote = remember(cloneStatus?.entity?.id) {
                                cloneStatus?.entity?.let { viewModel.readIsolatedSandboxNote(it) }.orEmpty()
                            }

                            CloneDetailScreen(
                                status = cloneStatus,
                                events = cloneEvents,
                                initialIsolatedNote = initialNote,
                                loadAppIcon = viewModel::loadAppIcon,
                                onBack = { navController.popBackStack() },
                                onVerifySurvival = viewModel::verifySurvivalAndIntegrity,
                                onLaunchClone = attemptLaunchClone,
                                onExportApk = startApkExport,
                                onShareApk = startApkShare,
                                onUpdatePolicies = viewModel::updateIsolationPolicies,
                                onSaveIsolatedNote = viewModel::saveIsolatedSandboxNote,
                                onDeleteClone = viewModel::deleteClone
                            )
                        }
                    }
                }
            }
        }
    }

    pendingDeployDialogEntity?.let { entity ->
        AlertDialog(
            onDismissRequest = { pendingDeployDialogEntity = null },
            title = { Text("Deploy Independent Clone") },
            text = {
                Text(
                    "The isolated clone package (${entity.clonedPackageName}) is archived and signed in VaultBox, but is not yet installed onto Android's launcher. Export or share the cloned .apk to install it alongside or independently of the main app — once installed, tapping Launch opens it directly even if the main app outside is uninstalled."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        pendingDeployDialogEntity = null
                        startApkExport(entity)
                    }
                ) {
                    Text("Export Cloned .APK")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        pendingDeployDialogEntity = null
                        startApkShare(entity)
                    }
                ) {
                    Text("Share .APK")
                }
            }
        )
    }
}
