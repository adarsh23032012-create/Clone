package com.example.weather

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class WeatherLocation(
    val name: String,
    val region: String,
    val latitude: Double,
    val longitude: Double
)

data class HourlyForecastPoint(
    val timeLabel: String,
    val tempCelsius: Double,
    val weatherCode: Int
)

data class DailyForecastPoint(
    val dayLabel: String,
    val weatherCode: Int,
    val minTempCelsius: Double,
    val maxTempCelsius: Double,
    val precipProbability: Int
)

data class WeatherForecast(
    val location: WeatherLocation,
    val currentTempCelsius: Double,
    val apparentTempCelsius: Double,
    val humidityPercent: Int,
    val windSpeedKmh: Double,
    val weatherCode: Int,
    val isDay: Boolean,
    val hourly: List<HourlyForecastPoint>,
    val daily: List<DailyForecastPoint>,
    val updatedTimestamp: Long,
    val isFromCache: Boolean = false
)

enum class WeatherCondition(val label: String) {
    CLEAR("Clear Sky"),
    PARTLY_CLOUDY("Partly Cloudy"),
    OVERCAST("Cloudy"),
    FOG("Foggy"),
    DRIZZLE("Light Drizzle"),
    RAIN("Rain"),
    SNOW("Snow"),
    THUNDERSTORM("Thunderstorm");

    companion object {
        fun fromWmoCode(code: Int): WeatherCondition = when (code) {
            0 -> CLEAR
            1, 2 -> PARTLY_CLOUDY
            3 -> OVERCAST
            45, 48 -> FOG
            51, 53, 55, 56, 57 -> DRIZZLE
            61, 63, 65, 66, 67, 80, 81, 82 -> RAIN
            71, 73, 75, 77, 85, 86 -> SNOW
            95, 96, 99 -> THUNDERSTORM
            else -> PARTLY_CLOUDY
        }
    }
}

class WeatherRepository(private val context: Context) {

    private val cacheFile = File(context.filesDir, "weather_forecast_cache.json")

    suspend fun fetchForecast(location: WeatherLocation): Result<WeatherForecast> =
        withContext(Dispatchers.IO) {
            runCatching {
                val urlStr =
                    "https://api.open-meteo.com/v1/forecast" +
                        "?latitude=${location.latitude}" +
                        "&longitude=${location.longitude}" +
                        "&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m" +
                        "&hourly=temperature_2m,weather_code" +
                        "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                        "&timezone=auto"

                val rawJson = httpGet(urlStr)
                cacheFile.writeText(rawJson)
                parseForecastJson(rawJson, location, isFromCache = false)
            }.recoverCatching { err ->
                if (cacheFile.exists()) {
                    val cached = cacheFile.readText()
                    parseForecastJson(cached, location, isFromCache = true)
                } else {
                    throw err
                }
            }
        }

    suspend fun searchCities(query: String): List<WeatherLocation> = withContext(Dispatchers.IO) {
        if (query.trim().length < 2) return@withContext PRESET_LOCATIONS
        runCatching {
            val encoded = URLEncoder.encode(query.trim(), "UTF-8")
            val urlStr =
                "https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=6&language=en&format=json"
            val raw = httpGet(urlStr)
            val root = JSONObject(raw)
            val results = root.optJSONArray("results") ?: return@withContext emptyList()
            buildList {
                for (i in 0 until results.length()) {
                    val obj = results.getJSONObject(i)
                    val name = obj.optString("name")
                    val admin1 = obj.optString("admin1")
                    val country = obj.optString("country")
                    val region = listOf(admin1, country).filter { it.isNotBlank() }.joinToString(", ")
                    add(
                        WeatherLocation(
                            name = name,
                            region = region,
                            latitude = obj.getDouble("latitude"),
                            longitude = obj.getDouble("longitude")
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun httpGet(urlString: String): String {
        val conn = (URL(urlString).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8000
            readTimeout = 8000
        }
        return conn.use {
            if (it.responseCode !in 200..299) {
                error("HTTP ${it.responseCode}")
            }
            it.inputStream.bufferedReader().use { reader -> reader.readText() }
        }
    }

    private inline fun <T> HttpURLConnection.use(block: (HttpURLConnection) -> T): T {
        return try {
            block(this)
        } finally {
            disconnect()
        }
    }

    internal fun parseForecastJson(
        rawJson: String,
        location: WeatherLocation,
        isFromCache: Boolean
    ): WeatherForecast {
        val root = JSONObject(rawJson)
        val current = root.getJSONObject("current")
        val currentTemp = current.getDouble("temperature_2m")
        val apparentTemp = current.optDouble("apparent_temperature", currentTemp)
        val humidity = current.optInt("relative_humidity_2m", 50)
        val windSpeed = current.optDouble("wind_speed_10m", 0.0)
        val weatherCode = current.optInt("weather_code", 0)
        val isDay = current.optInt("is_day", 1) == 1

        val currentTimeStr = current.optString("time", "")
        val hourlyObj = root.getJSONObject("hourly")
        val hTimes = hourlyObj.getJSONArray("time")
        val hTemps = hourlyObj.getJSONArray("temperature_2m")
        val hCodes = hourlyObj.getJSONArray("weather_code")

        var startIdx = 0
        if (currentTimeStr.length >= 13) {
            val prefix = currentTimeStr.substring(0, 13)
            for (i in 0 until hTimes.length()) {
                if (hTimes.getString(i).startsWith(prefix)) {
                    startIdx = i
                    break
                }
            }
        }
        val hourlyList = mutableListOf<HourlyForecastPoint>()
        val endIdx = minOf(hTimes.length(), startIdx + 14)
        for (i in startIdx until endIdx) {
            val iso = hTimes.getString(i)
            val label = if (i == startIdx) "Now" else iso.substringAfter('T', iso).take(5)
            hourlyList.add(
                HourlyForecastPoint(
                    timeLabel = label,
                    tempCelsius = hTemps.getDouble(i),
                    weatherCode = hCodes.getInt(i)
                )
            )
        }

        val dailyObj = root.getJSONObject("daily")
        val dTimes = dailyObj.getJSONArray("time")
        val dCodes = dailyObj.getJSONArray("weather_code")
        val dMax = dailyObj.getJSONArray("temperature_2m_max")
        val dMin = dailyObj.getJSONArray("temperature_2m_min")
        val dPrecip = dailyObj.optJSONArray("precipitation_probability_max")

        val inFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val outFmt = SimpleDateFormat("EEE", Locale.getDefault())
        val dailyList = mutableListOf<DailyForecastPoint>()
        for (i in 0 until dTimes.length()) {
            val dateStr = dTimes.getString(i)
            val dayLabel = if (i == 0) {
                "Today"
            } else {
                runCatching {
                    val d: Date? = inFmt.parse(dateStr)
                    if (d != null) outFmt.format(d) else dateStr
                }.getOrDefault(dateStr)
            }
            dailyList.add(
                DailyForecastPoint(
                    dayLabel = dayLabel,
                    weatherCode = dCodes.getInt(i),
                    minTempCelsius = dMin.getDouble(i),
                    maxTempCelsius = dMax.getDouble(i),
                    precipProbability = dPrecip?.optInt(i, 0) ?: 0
                )
            )
        }

        return WeatherForecast(
            location = location,
            currentTempCelsius = currentTemp,
            apparentTempCelsius = apparentTemp,
            humidityPercent = humidity,
            windSpeedKmh = windSpeed,
            weatherCode = weatherCode,
            isDay = isDay,
            hourly = hourlyList,
            daily = dailyList,
            updatedTimestamp = System.currentTimeMillis(),
            isFromCache = isFromCache
        )
    }

    companion object {
        val PRESET_LOCATIONS = listOf(
            WeatherLocation("San Francisco", "California, United States", 37.7749, -122.4194),
            WeatherLocation("New York", "New York, United States", 40.7128, -74.0060),
            WeatherLocation("London", "United Kingdom", 51.5074, -0.1278),
            WeatherLocation("Tokyo", "Japan", 35.6762, 139.6503),
            WeatherLocation("New Delhi", "India", 28.6139, 77.2090)
        )
    }
}
