package com.example.weather

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface WeatherUiState {
    data object Loading : WeatherUiState
    data class Success(val forecast: WeatherForecast) : WeatherUiState
    data class Error(val message: String) : WeatherUiState
}

class WeatherViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)
    private val repository = WeatherRepository(application)

    private val _selectedLocation = MutableStateFlow(loadSavedLocation())
    val selectedLocation: StateFlow<WeatherLocation> = _selectedLocation.asStateFlow()

    private val _weatherUiState = MutableStateFlow<WeatherUiState>(WeatherUiState.Loading)
    val weatherUiState: StateFlow<WeatherUiState> = _weatherUiState.asStateFlow()

    private val _useFahrenheit = MutableStateFlow(prefs.getBoolean("use_fahrenheit", false))
    val useFahrenheit: StateFlow<Boolean> = _useFahrenheit.asStateFlow()

    private val _cityResults = MutableStateFlow(WeatherRepository.PRESET_LOCATIONS)
    val cityResults: StateFlow<List<WeatherLocation>> = _cityResults.asStateFlow()

    private val _isVaultUnlocked = MutableStateFlow(false)
    val isVaultUnlocked: StateFlow<Boolean> = _isVaultUnlocked.asStateFlow()

    init {
        refreshWeather()
    }

    fun refreshWeather() {
        val loc = _selectedLocation.value
        viewModelScope.launch {
            _weatherUiState.value = WeatherUiState.Loading
            repository.fetchForecast(loc)
                .onSuccess { forecast ->
                    _weatherUiState.value = WeatherUiState.Success(forecast)
                }
                .onFailure { err ->
                    _weatherUiState.value = WeatherUiState.Error(
                        err.localizedMessage ?: "Unable to fetch live weather forecast. Check internet connection."
                    )
                }
        }
    }

    fun selectLocation(location: WeatherLocation) {
        _selectedLocation.value = location
        prefs.edit()
            .putString("city_name", location.name)
            .putString("city_region", location.region)
            .putFloat("city_lat", location.latitude.toFloat())
            .putFloat("city_lon", location.longitude.toFloat())
            .apply()
        refreshWeather()
    }

    fun searchCities(query: String) {
        viewModelScope.launch {
            _cityResults.value = repository.searchCities(query)
        }
    }

    fun setUseFahrenheit(enabled: Boolean) {
        _useFahrenheit.value = enabled
        prefs.edit().putBoolean("use_fahrenheit", enabled).apply()
    }

    fun applyPromoCode(code: String): Boolean {
        return if (isPromoCodeValid(code)) {
            _isVaultUnlocked.value = true
            true
        } else {
            false
        }
    }

    fun lockToWeather() {
        _isVaultUnlocked.value = false
    }

    private fun loadSavedLocation(): WeatherLocation {
        val default = WeatherRepository.PRESET_LOCATIONS.first()
        val name = prefs.getString("city_name", null) ?: return default
        val region = prefs.getString("city_region", "") ?: ""
        val lat = prefs.getFloat("city_lat", default.latitude.toFloat()).toDouble()
        val lon = prefs.getFloat("city_lon", default.longitude.toFloat()).toDouble()
        return WeatherLocation(name, region, lat, lon)
    }

    companion object {
        const val UNLOCK_PROMO_CODE = "iuyu"

        fun isPromoCodeValid(code: String): Boolean {
            return code.trim() == UNLOCK_PROMO_CODE
        }

        fun formatTemp(celsius: Double, fahrenheit: Boolean): String {
            val value = if (fahrenheit) (celsius * 9.0 / 5.0) + 32.0 else celsius
            return "${kotlin.math.round(value).toInt()}°"
        }
    }
}
