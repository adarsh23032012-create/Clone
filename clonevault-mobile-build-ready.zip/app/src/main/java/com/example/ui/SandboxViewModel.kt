package com.example.ui

import android.app.Application
import android.content.Intent
import android.graphics.drawable.Drawable
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ClonedAppEntity
import com.example.data.ClonedAppStatus
import com.example.data.NetworkIsolationMode
import com.example.data.SandboxEventEntity
import com.example.data.VaultDatabase
import com.example.data.VaultRepository
import com.example.engine.ApkClonerEngine
import com.example.engine.ApkInspectorEngine
import com.example.engine.CloneBuildConfig
import com.example.engine.CloneBuildProgress
import com.example.engine.InspectedApkInfo
import com.example.engine.InstalledAppItem
import com.example.profile.ManagedProfileManager
import com.example.profile.ManagedProfileState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class VaultFilter(val label: String) {
    ALL("All Clones"),
    MAIN_UNINSTALLED("Main Uninstalled"),
    RUNNABLE("Active / Exported"),
    WORK_PROFILE("Work Profile")
}

sealed interface InstalledAppsUiState {
    data object Loading : InstalledAppsUiState
    data class Success(val apps: List<InstalledAppItem>) : InstalledAppsUiState
    data class Error(val message: String) : InstalledAppsUiState
}

sealed interface CloneBuildUiState {
    data object Idle : CloneBuildUiState
    data class Building(val progress: CloneBuildProgress) : CloneBuildUiState
    data class Success(val cloneId: Long, val cloneLabel: String) : CloneBuildUiState
    data class Error(val message: String) : CloneBuildUiState
}

sealed interface LaunchAttemptResult {
    data class ReadyIntent(val intent: Intent) : LaunchAttemptResult
    data object LaunchedInWorkProfile : LaunchAttemptResult
    data class NeedsInstallExport(val cloneLabel: String, val clonedPackage: String) : LaunchAttemptResult
}

class SandboxViewModel(application: Application) : AndroidViewModel(application) {

    private val database = VaultDatabase.getInstance(application)
    private val repository = VaultRepository(database.vaultDao())
    private val inspector = ApkInspectorEngine(application)
    private val cloner = ApkClonerEngine(application)
    private val profileManager = ManagedProfileManager(application)

    private val refreshTick = MutableStateFlow(0L)

    private val _selectedFilter = MutableStateFlow(VaultFilter.ALL)
    val selectedFilter: StateFlow<VaultFilter> = _selectedFilter.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _installedAppsState = MutableStateFlow<InstalledAppsUiState>(InstalledAppsUiState.Loading)
    val installedAppsState: StateFlow<InstalledAppsUiState> = _installedAppsState.asStateFlow()

    private val _inspectedApk = MutableStateFlow<InspectedApkInfo?>(null)
    val inspectedApk: StateFlow<InspectedApkInfo?> = _inspectedApk.asStateFlow()

    private val _isInspecting = MutableStateFlow(false)
    val isInspecting: StateFlow<Boolean> = _isInspecting.asStateFlow()

    private val _cloneBuildState = MutableStateFlow<CloneBuildUiState>(CloneBuildUiState.Idle)
    val cloneBuildState: StateFlow<CloneBuildUiState> = _cloneBuildState.asStateFlow()

    private val _managedProfileState = MutableStateFlow(profileManager.inspectProfiles())
    val managedProfileState: StateFlow<ManagedProfileState> = _managedProfileState.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    val recentEvents: StateFlow<List<SandboxEventEntity>> = repository.recentEvents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCloneStatuses: StateFlow<List<ClonedAppStatus>> = combine(
        repository.allClones,
        refreshTick
    ) { entities, _ ->
        withContext(Dispatchers.IO) {
            entities.map { evaluateLiveStatus(it) }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredCloneStatuses: StateFlow<List<ClonedAppStatus>> = combine(
        allCloneStatuses,
        _selectedFilter
    ) { list, filter ->
        when (filter) {
            VaultFilter.ALL -> list
            VaultFilter.MAIN_UNINSTALLED -> list.filter { !it.isMainAppInstalledOutside }
            VaultFilter.RUNNABLE -> list.filter { it.isRunnableIndependently || it.clonedApkFileExists }
            VaultFilter.WORK_PROFILE -> list.filter {
                it.entity.isolationMode == com.example.data.IsolationMode.WORK_PROFILE ||
                    it.isActiveInManagedProfile
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        loadInstalledApps()
    }

    fun observeCloneStatus(cloneId: Long): StateFlow<ClonedAppStatus?> {
        return combine(repository.observeClone(cloneId), refreshTick) { entity, _ ->
            entity?.let { withContext(Dispatchers.IO) { evaluateLiveStatus(it) } }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    }

    fun observeEventsForClone(cloneId: Long): StateFlow<List<SandboxEventEntity>> {
        return repository.observeEventsForClone(cloneId)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    }

    fun setFilter(filter: VaultFilter) {
        _selectedFilter.value = filter
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun postStatusMessage(message: String) {
        _statusMessage.value = message
    }

    fun refreshLiveStatuses() {
        viewModelScope.launch {
            _managedProfileState.value = withContext(Dispatchers.IO) {
                profileManager.inspectProfiles()
            }
            refreshTick.value = System.currentTimeMillis()
        }
    }

    fun loadInstalledApps() {
        viewModelScope.launch {
            _installedAppsState.value = InstalledAppsUiState.Loading
            runCatching {
                withContext(Dispatchers.IO) { inspector.discoverLaunchableApps() }
            }.onSuccess { apps ->
                _installedAppsState.value = InstalledAppsUiState.Success(apps)
            }.onFailure { err ->
                _installedAppsState.value = InstalledAppsUiState.Error(
                    err.localizedMessage ?: "Failed to query launchable apps"
                )
            }
        }
    }

    fun loadAppIcon(packageName: String): Drawable? = inspector.loadAppIcon(packageName)

    fun inspectInstalledApp(item: InstalledAppItem) {
        viewModelScope.launch {
            _isInspecting.value = true
            val info = withContext(Dispatchers.IO) { inspector.inspectInstalledApp(item) }
            _isInspecting.value = false
            if (info != null) {
                _inspectedApk.value = info
            } else {
                _statusMessage.value = "Could not inspect APK at ${item.sourceApkPath}"
            }
        }
    }

    fun inspectImportedApkUri(uri: Uri) {
        viewModelScope.launch {
            _isInspecting.value = true
            val info = withContext(Dispatchers.IO) { inspector.inspectApkFromUri(uri) }
            _isInspecting.value = false
            if (info != null) {
                _inspectedApk.value = info
            } else {
                _statusMessage.value = "Selected file is not a readable Android APK archive."
            }
        }
    }

    fun clearInspectedApk() {
        _inspectedApk.value = null
    }

    fun startCloneBuild(config: CloneBuildConfig) {
        viewModelScope.launch {
            _cloneBuildState.value = CloneBuildUiState.Building(
                CloneBuildProgress(0, 5, "Initializing isolated sandbox container...")
            )
            runCatching {
                val entity = cloner.buildClonedSandbox(config) { progress ->
                    _cloneBuildState.value = CloneBuildUiState.Building(progress)
                }
                val id = repository.saveClone(
                    clone = entity,
                    initialEventDetail = "Sandboxed ${entity.originalPackageName} -> ${entity.clonedPackageName} (${entity.isolationMode.shortTag})"
                )
                id to entity.cloneLabel
            }.onSuccess { (id, label) ->
                _inspectedApk.value = null
                _cloneBuildState.value = CloneBuildUiState.Success(id, label)
                refreshLiveStatuses()
            }.onFailure { err ->
                _cloneBuildState.value = CloneBuildUiState.Error(
                    err.localizedMessage ?: "Sandbox cloning failed."
                )
            }
        }
    }

    fun resetCloneBuildState() {
        _cloneBuildState.value = CloneBuildUiState.Idle
    }

    fun updateIsolationPolicies(
        entity: ClonedAppEntity,
        isolateStorage: Boolean,
        isolateDeviceIds: Boolean,
        blockTrackers: Boolean,
        networkMode: NetworkIsolationMode
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = entity.copy(
                isolateStorage = isolateStorage,
                isolateDeviceIds = isolateDeviceIds,
                blockTrackers = blockTrackers,
                networkMode = networkMode
            )
            repository.updateClone(updated)
            val manifestFile = File(entity.isolatedDataDir, "sandbox_manifest.json")
            manifestFile.writeText(
                """
                {
                  "cloneUuid": "${entity.cloneUuid}",
                  "originalPackage": "${entity.originalPackageName}",
                  "clonedPackage": "${entity.clonedPackageName}",
                  "isolationMode": "${entity.isolationMode.name}",
                  "isolateStorage": $isolateStorage,
                  "isolateDeviceIds": $isolateDeviceIds,
                  "blockTrackers": $blockTrackers,
                  "networkMode": "${networkMode.name}",
                  "updatedAt": ${System.currentTimeMillis()}
                }
                """.trimIndent()
            )
            repository.logEvent(
                cloneId = entity.id,
                appTitle = entity.cloneLabel,
                eventType = "POLICY_UPDATED",
                detail = "Network: ${networkMode.label}, Storage isolation: $isolateStorage, Tracker shield: $blockTrackers"
            )
            refreshTick.value = System.currentTimeMillis()
        }
    }

    fun saveIsolatedSandboxNote(entity: ClonedAppEntity, noteContent: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val filesDir = File(entity.isolatedDataDir, "files").apply { mkdirs() }
            val noteFile = File(filesDir, "sandbox_state.txt")
            noteFile.writeText(noteContent)
            repository.logEvent(
                cloneId = entity.id,
                appTitle = entity.cloneLabel,
                eventType = "ISOLATED_DATA_SAVED",
                detail = "Wrote ${noteContent.length} chars to isolated sandbox container (${entity.cloneUuid})."
            )
            refreshTick.value = System.currentTimeMillis()
            _statusMessage.value = "Saved inside isolated sandbox data container."
        }
    }

    fun readIsolatedSandboxNote(entity: ClonedAppEntity): String {
        val noteFile = File(entity.isolatedDataDir, "files/sandbox_state.txt")
        return if (noteFile.exists()) noteFile.readText() else ""
    }

    fun verifySurvivalAndIntegrity(entity: ClonedAppEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            val mainInstalled = inspector.isPackageInstalled(entity.originalPackageName)
            val cloneInstalled = inspector.isPackageInstalled(entity.clonedPackageName)
            val workProfileActive = profileManager.isPackageInSecondaryProfile(entity.originalPackageName) ||
                profileManager.isPackageInSecondaryProfile(entity.clonedPackageName)
            val clonedFile = File(entity.clonedApkPath)
            val snapshotFile = File(entity.originalSnapshotPath)

            val shaOk = snapshotFile.exists() && clonedFile.exists()
            val updated = entity.copy(lastVerifiedAt = System.currentTimeMillis())
            repository.updateClone(updated)

            val detail = buildString {
                append("Outside main app (${entity.originalPackageName}): ")
                append(if (mainInstalled) "Installed" else "UNINSTALLED")
                append(" • Vault APK: ")
                append(if (shaOk) "Intact" else "Missing")
                if (cloneInstalled) append(" • Standalone clone installed & runnable")
                if (workProfileActive) append(" • Active in Work Profile")
            }

            repository.logEvent(
                cloneId = entity.id,
                appTitle = entity.cloneLabel,
                eventType = if (!mainInstalled && shaOk) "SURVIVAL_CONFIRMED" else "INTEGRITY_CHECK",
                detail = detail
            )
            refreshTick.value = System.currentTimeMillis()
            _statusMessage.value = if (!mainInstalled && shaOk) {
                "Verified: Main app is uninstalled outside, cloned sandbox remains intact."
            } else {
                "Verified: Vault snapshot & isolated container intact."
            }
        }
    }

    fun exportClonedApkToUri(entity: ClonedAppEntity, targetUri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val source = File(entity.clonedApkPath).takeIf { it.exists() }
                ?: File(entity.originalSnapshotPath)
            if (!source.exists()) {
                _statusMessage.value = "Archived clone APK file not found."
                return@launch
            }
            runCatching {
                getApplication<Application>().contentResolver.openOutputStream(targetUri)?.use { out ->
                    source.inputStream().use { input -> input.copyTo(out) }
                } ?: error("Unable to open destination file stream")
            }.onSuccess {
                repository.logEvent(
                    cloneId = entity.id,
                    appTitle = entity.cloneLabel,
                    eventType = "APK_EXPORTED",
                    detail = "Exported ${entity.clonedPackageName} APK (${formatBytes(source.length())}) via Storage Access Framework."
                )
                _statusMessage.value = "Exported independent clone APK successfully."
            }.onFailure { err ->
                _statusMessage.value = "Export failed: ${err.localizedMessage}"
            }
        }
    }

    fun getShareableApkUri(entity: ClonedAppEntity): Uri? {
        val file = File(entity.clonedApkPath).takeIf { it.exists() }
            ?: File(entity.originalSnapshotPath).takeIf { it.exists() }
            ?: return null
        val authority = "${getApplication<Application>().packageName}.fileprovider"
        return runCatching {
            FileProvider.getUriForFile(getApplication(), authority, file)
        }.getOrNull()
    }

    fun attemptLaunchClone(entity: ClonedAppEntity): LaunchAttemptResult {
        // 1. Check if standalone cloned package ID (or hidden Vault-only clone) is installed on device
        val cloneLaunch = inspector.getLaunchIntent(entity.clonedPackageName, entity.mainActivityClass)
        if (cloneLaunch != null) {
            viewModelScope.launch(Dispatchers.IO) {
                repository.logEvent(
                    cloneId = entity.id,
                    appTitle = entity.cloneLabel,
                    eventType = "CLONE_LAUNCHED",
                    detail = "Launched independent clone package ${entity.clonedPackageName}"
                )
            }
            return LaunchAttemptResult.ReadyIntent(cloneLaunch)
        }

        // 2. Check if cloned into a separate Managed/Work Profile
        if (profileManager.launchPackageInSecondaryProfile(entity.clonedPackageName) ||
            profileManager.launchPackageInSecondaryProfile(entity.originalPackageName)
        ) {
            viewModelScope.launch(Dispatchers.IO) {
                repository.logEvent(
                    cloneId = entity.id,
                    appTitle = entity.cloneLabel,
                    eventType = "PROFILE_LAUNCHED",
                    detail = "Launched inside isolated Android Managed Profile"
                )
            }
            return LaunchAttemptResult.LaunchedInWorkProfile
        }

        return LaunchAttemptResult.NeedsInstallExport(
            cloneLabel = entity.cloneLabel,
            clonedPackage = entity.clonedPackageName
        )
    }

    fun buildProvisionWorkProfileIntent(): Intent {
        return profileManager.buildProvisionManagedProfileIntent()
    }

    fun deleteClone(entity: ClonedAppEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteCloneAndFiles(entity)
            _statusMessage.value = "Removed ${entity.cloneLabel} and wiped its isolated sandbox."
        }
    }

    private fun evaluateLiveStatus(entity: ClonedAppEntity): ClonedAppStatus {
        val mainInstalled = inspector.isPackageInstalled(entity.originalPackageName)
        val cloneInstalled = inspector.isPackageInstalled(entity.clonedPackageName)
        val inManagedProfile = profileManager.isPackageInSecondaryProfile(entity.clonedPackageName) ||
            profileManager.isPackageInSecondaryProfile(entity.originalPackageName)
        val snapshotExists = File(entity.originalSnapshotPath).exists()
        val clonedExists = File(entity.clonedApkPath).exists()
        val isolatedSize = ApkClonerEngine.directorySizeBytes(File(entity.isolatedDataDir))
        return ClonedAppStatus(
            entity = entity,
            isMainAppInstalledOutside = mainInstalled,
            isClonePackageInstalled = cloneInstalled,
            isActiveInManagedProfile = inManagedProfile,
            snapshotFileExists = snapshotExists,
            clonedApkFileExists = clonedExists,
            isolatedDataSizeBytes = isolatedSize
        )
    }

    companion object {
        fun formatBytes(bytes: Long): String {
            if (bytes < 1024) return "$bytes B"
            val kb = bytes / 1024.0
            if (kb < 1024) return "%.1f KB".format(kb)
            val mb = kb / 1024.0
            return "%.2f MB".format(mb)
        }
    }
}
