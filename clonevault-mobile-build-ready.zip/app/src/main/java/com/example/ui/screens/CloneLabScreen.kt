package com.example.ui.screens

import android.graphics.drawable.Drawable
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.IsolationMode
import com.example.data.NetworkIsolationMode
import com.example.engine.ApkClonerEngine
import com.example.engine.CloneBuildConfig
import com.example.engine.InspectedApkInfo
import com.example.engine.InstalledAppItem
import com.example.ui.CloneBuildUiState
import com.example.ui.InstalledAppsUiState
import com.example.ui.SandboxViewModel
import com.example.ui.components.AppIconThumbnail
import com.example.ui.theme.JetBrainsMonoFamily

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CloneLabScreen(
    installedAppsState: InstalledAppsUiState,
    searchQuery: String,
    inspectedApk: InspectedApkInfo?,
    isInspecting: Boolean,
    cloneBuildState: CloneBuildUiState,
    onSearchQueryChange: (String) -> Unit,
    onReloadApps: () -> Unit,
    onImportApkClick: () -> Unit,
    onInspectInstalledApp: (InstalledAppItem) -> Unit,
    onDismissInspector: () -> Unit,
    onStartCloneBuild: (CloneBuildConfig) -> Unit,
    onResetBuildState: () -> Unit,
    onNavigateToCloneDetail: (Long) -> Unit,
    loadAppIcon: (String) -> Drawable?,
    modifier: Modifier = Modifier
) {
    var showSystemApps by rememberSaveable { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 840.dp)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 104.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Clone Lab",
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Select an installed app or import an .apk to isolate",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(
                        onClick = onReloadApps,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("reload_installed_apps_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "Reload installed apps",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            item {
                Card(
                    onClick = onImportApkClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("import_external_apk_card"),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.primary
                        ) {
                            Icon(
                                imageVector = Icons.Filled.FolderOpen,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Import External .APK File",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Pick any APK via Android Storage Access Framework (zero storage permissions required).",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_installed_apps_input"),
                    placeholder = { Text("Search apps or package IDs...") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Filled.Search, contentDescription = null)
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchQueryChange("") }) {
                                Icon(imageVector = Icons.Filled.Close, contentDescription = "Clear search")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp)
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Installed Device Apps",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    FilterChip(
                        selected = showSystemApps,
                        onClick = { showSystemApps = !showSystemApps },
                        label = { Text("Include System Apps") },
                        modifier = Modifier.testTag("toggle_system_apps_chip")
                    )
                }
            }

            when (installedAppsState) {
                is InstalledAppsUiState.Loading -> {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator()
                        }
                    }
                }

                is InstalledAppsUiState.Error -> {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                        ) {
                            Text(
                                text = installedAppsState.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    }
                }

                is InstalledAppsUiState.Success -> {
                    val filtered = installedAppsState.apps.filter { app ->
                        val matchesSystem = showSystemApps || !app.isSystemApp
                        val q = searchQuery.trim()
                        val matchesQuery = q.isEmpty() ||
                            app.appName.contains(q, ignoreCase = true) ||
                            app.packageName.contains(q, ignoreCase = true)
                        matchesSystem && matchesQuery
                    }

                    if (filtered.isEmpty()) {
                        item {
                            Text(
                                text = "No matching launchable apps found. Try toggling system apps or importing an .apk file above.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(vertical = 20.dp)
                            )
                        }
                    } else {
                        items(filtered, key = { it.packageName }) { app ->
                            val icon = remember(app.packageName) { loadAppIcon(app.packageName) }
                            InstalledAppRowCard(
                                item = app,
                                iconDrawable = icon,
                                onCloneClick = { onInspectInstalledApp(app) }
                            )
                        }
                    }
                }
            }
        }

        if (isInspecting) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.scrim.copy(alpha = 0.55f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Card(shape = RoundedCornerShape(18.dp)) {
                        Row(
                            modifier = Modifier.padding(20.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(28.dp))
                            Text(
                                text = "Inspecting APK manifest & binary...",
                                style = MaterialTheme.typography.titleSmall
                            )
                        }
                    }
                }
            }
        }
    }

    if (inspectedApk != null) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = onDismissInspector,
            sheetState = sheetState,
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            CloneConfigSheetContent(
                apk = inspectedApk,
                onDismiss = onDismissInspector,
                onConfirmBuild = onStartCloneBuild
            )
        }
    }

    when (cloneBuildState) {
        is CloneBuildUiState.Building -> {
            val progress = cloneBuildState.progress
            AlertDialog(
                onDismissRequest = {},
                title = { Text("Building Isolated Clone") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        LinearProgressIndicator(
                            progress = {
                                (progress.stepIndex.toFloat() / progress.totalSteps.coerceAtLeast(1)).coerceIn(0f, 1f)
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            text = "Step ${progress.stepIndex}/${progress.totalSteps}: ${progress.statusMessage}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                },
                confirmButton = {}
            )
        }

        is CloneBuildUiState.Success -> {
            AlertDialog(
                onDismissRequest = onResetBuildState,
                icon = {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                },
                title = { Text("Sandbox Clone Ready") },
                text = {
                    Text(
                        "${cloneBuildState.cloneLabel} has been isolated inside VaultBox with its own sandbox directory and independent clone APK. Uninstalling the main app outside will not affect this clone."
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val id = cloneBuildState.cloneId
                            onResetBuildState()
                            onNavigateToCloneDetail(id)
                        },
                        modifier = Modifier.testTag("view_built_clone_button")
                    ) {
                        Text("Open Sandbox")
                    }
                },
                dismissButton = {
                    TextButton(onClick = onResetBuildState) {
                        Text("Stay in Lab")
                    }
                }
            )
        }

        is CloneBuildUiState.Error -> {
            AlertDialog(
                onDismissRequest = onResetBuildState,
                title = { Text("Cloning Failed") },
                text = { Text(cloneBuildState.message) },
                confirmButton = {
                    TextButton(onClick = onResetBuildState) {
                        Text("OK")
                    }
                }
            )
        }

        CloneBuildUiState.Idle -> Unit
    }
}

@Composable
private fun InstalledAppRowCard(
    item: InstalledAppItem,
    iconDrawable: Drawable?,
    onCloneClick: () -> Unit
) {
    Card(
        onClick = onCloneClick,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("installed_app_card_${item.packageName}"),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AppIconThumbnail(
                appName = item.appName,
                iconDrawable = iconDrawable,
                size = 46.dp
            )
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = item.appName,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = item.packageName,
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "v${item.versionName} • ${SandboxViewModel.formatBytes(item.apkSizeBytes)} • SDK ${item.minSdk}-${item.targetSdk}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            OutlinedButton(
                onClick = onCloneClick,
                modifier = Modifier.testTag("clone_button_${item.packageName}"),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Sandbox")
            }
        }
    }
}

@Composable
private fun CloneConfigSheetContent(
    apk: InspectedApkInfo,
    onDismiss: () -> Unit,
    onConfirmBuild: (CloneBuildConfig) -> Unit
) {
    var cloneLabel by remember(apk.packageName) { mutableStateOf("${apk.appName} (Sandbox)") }
    var suffixTag by remember(apk.packageName) { mutableStateOf("s1") }
    var clonedPackage by remember(apk.packageName) {
        mutableStateOf(ApkClonerEngine.generateClonedPackageName(apk.packageName, "s1"))
    }
    var selectedMode by remember { mutableStateOf(IsolationMode.STANDALONE_CLONE) }
    var isolateStorage by remember { mutableStateOf(true) }
    var isolateDeviceIds by remember { mutableStateOf(true) }
    var blockTrackers by remember { mutableStateOf(true) }
    var hideFromLauncher by remember { mutableStateOf(true) }
    var networkMode by remember { mutableStateOf(NetworkIsolationMode.TRACKER_FILTER) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Security,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
            Column {
                Text(
                    text = "Configure Sandbox Clone",
                    style = MaterialTheme.typography.titleLarge
                )
                Text(
                    text = "${apk.appName} • ${SandboxViewModel.formatBytes(apk.apkSizeBytes)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Binary Telemetry Summary
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surfaceContainer,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "Original ID: ${apk.packageName}",
                    style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFamily),
                    color = MaterialTheme.colorScheme.secondary
                )
                Text(
                    text = "DEX: ${apk.dexCount} • Perms: ${apk.permissions.size} • ABIs: ${
                        apk.nativeAbis.ifEmpty { listOf("universal") }.joinToString(", ")
                    }",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Cert SHA-256: ${apk.signingSha256.take(24)}…",
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (apk.hasSplitApks) {
                    Text(
                        text = "Split-APK bundle detected: import a universal .apk if this app relies on split native libraries.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                }
            }
        }

        OutlinedTextField(
            value = cloneLabel,
            onValueChange = { cloneLabel = it },
            label = { Text("Clone Display Label") },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("clone_label_input"),
            shape = RoundedCornerShape(12.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = suffixTag,
                onValueChange = { raw ->
                    suffixTag = raw.take(8)
                    clonedPackage = ApkClonerEngine.generateClonedPackageName(apk.packageName, raw)
                },
                label = { Text("Slot Tag") },
                singleLine = true,
                modifier = Modifier.width(108.dp),
                shape = RoundedCornerShape(12.dp)
            )
            OutlinedTextField(
                value = clonedPackage,
                onValueChange = { clonedPackage = it },
                label = { Text("Isolated Package ID") },
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .testTag("cloned_package_input"),
                shape = RoundedCornerShape(12.dp)
            )
        }

        Text("Isolation Architecture", style = MaterialTheme.typography.titleSmall)
        IsolationMode.entries.forEach { mode ->
            Surface(
                onClick = { selectedMode = mode },
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(
                    width = 1.dp,
                    color = if (selectedMode == mode) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.outlineVariant
                    }
                ),
                color = if (selectedMode == mode) {
                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
                } else {
                    MaterialTheme.colorScheme.surfaceContainerLow
                }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selectedMode == mode,
                        onClick = { selectedMode = mode }
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(mode.displayName, style = MaterialTheme.typography.titleSmall)
                        Text(
                            mode.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        Text("Sandbox Privacy & Stealth Policies", style = MaterialTheme.typography.titleSmall)
        PolicySwitchRow("Hide from Home Screen (Vault-Only)", hideFromLauncher) {
            hideFromLauncher = it
        }
        Text(
            text = if (hideFromLauncher) {
                "Removes the launcher icon so the cloned app stays off your home screen and app drawer, launching only from inside VaultBox."
            } else {
                "Keeps a separate launcher icon on your home screen for the cloned package."
            },
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        PolicySwitchRow("Isolate Container Storage", isolateStorage) { isolateStorage = it }
        PolicySwitchRow("Virtualize Device Identifiers", isolateDeviceIds) { isolateDeviceIds = it }
        PolicySwitchRow("Block Background Trackers", blockTrackers) { blockTrackers = it }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            NetworkIsolationMode.entries.forEach { mode ->
                FilterChip(
                    selected = networkMode == mode,
                    onClick = { networkMode = mode },
                    label = { Text(mode.label, style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp, bottom = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Cancel")
            }
            Button(
                onClick = {
                    onConfirmBuild(
                        CloneBuildConfig(
                            inspectedApk = apk,
                            cloneLabel = cloneLabel,
                            clonedPackageName = clonedPackage.ifBlank {
                                ApkClonerEngine.generateClonedPackageName(apk.packageName, "s1")
                            },
                            isolationMode = selectedMode,
                            isolateStorage = isolateStorage,
                            isolateDeviceIds = isolateDeviceIds,
                            blockTrackers = blockTrackers,
                            networkMode = networkMode,
                            hideFromLauncher = hideFromLauncher
                        )
                    )
                },
                modifier = Modifier
                    .weight(1.5f)
                    .testTag("build_sandbox_clone_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Build,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Build & Sandbox Clone")
            }
        }
    }
}

@Composable
private fun PolicySwitchRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
