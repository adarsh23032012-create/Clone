package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Obsidian Security Palette
val ObsidianBg = Color(0xFF0B0F14)
val SlateSurface = Color(0xFF121821)
val SlateSurfaceLow = Color(0xFF0F141C)
val SlateContainer = Color(0xFF1A2230)
val SlateContainerHigh = Color(0xFF242F42)
val SlateOutline = Color(0xFF334158)
val SlateOutlineVariant = Color(0xFF212B3B)

val CyberMint = Color(0xFF00E5A3)
val OnCyberMint = Color(0xFF003826)
val CyberMintContainer = Color(0xFF044D36)
val OnCyberMintContainer = Color(0xFF8CFFCE)

val CyberCobalt = Color(0xFF5B9BFF)
val OnCyberCobalt = Color(0xFF002B66)
val CyberCobaltContainer = Color(0xFF163A70)
val OnCyberCobaltContainer = Color(0xFFD6E4FF)

val AmberShield = Color(0xFFFFB84D)
val OnAmberShield = Color(0xFF452A00)
val AmberShieldContainer = Color(0xFF5C3A00)
val OnAmberShieldContainer = Color(0xFFFFDEA8)

val DangerCrimson = Color(0xFFFF6B7A)
val OnDangerCrimson = Color(0xFF5A0011)
val DangerContainer = Color(0xFF7D0E21)
val OnDangerContainer = Color(0xFFFFDADE)

val TextPrimaryDark = Color(0xFFEAF0F8)
val TextSecondaryDark = Color(0xFF9AA8BE)

// Light Precision Lab Palette
val AlabasterBg = Color(0xFFF3F6FA)
val PureSurface = Color(0xFFFFFFFF)
val CoolContainer = Color(0xFFE7EDF5)
val CoolContainerHigh = Color(0xFFDCE4F0)
val CoolOutline = Color(0xFF94A3B8)
val CoolOutlineVariant = Color(0xFFD2DCE8)

val EmeraldPrimary = Color(0xFF007A55)
val EmeraldContainer = Color(0xFFBFF5DF)
val OnEmeraldContainer = Color(0xFF002114)

val CobaltSecondary = Color(0xFF2463EB)
val CobaltContainer = Color(0xFFDCE6FF)
val OnCobaltContainer = Color(0xFF00194A)

val AmberTertiary = Color(0xFFB45309)
val AmberContainer = Color(0xFFFFE5C2)
val OnAmberContainer = Color(0xFF381900)

val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
