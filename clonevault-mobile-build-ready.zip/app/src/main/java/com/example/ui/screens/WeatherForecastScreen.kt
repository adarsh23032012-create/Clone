package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Thunderstorm
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.weather.DailyForecastPoint
import com.example.weather.HourlyForecastPoint
import com.example.weather.WeatherCondition
import com.example.weather.WeatherForecast
import com.example.weather.WeatherLocation
import com.example.weather.WeatherUiState
import com.example.weather.WeatherViewModel
import kotlin.math.roundToInt

@Composable
fun WeatherForecastScreen(
    uiState: WeatherUiState,
    selectedLocation: WeatherLocation,
    useFahrenheit: Boolean,
    cityResults: List<WeatherLocation>,
    onRefresh: () -> Unit,
    onToggleFahrenheit: (Boolean) -> Unit,
    onSearchCities: (String) -> Unit,
    onSelectLocation: (WeatherLocation) -> Unit,
    onPromoCodeSubmit: (String) -> Boolean,
    modifier: Modifier = Modifier
) {
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showCityPicker by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .statusBarsPadding()
                .navigationBarsPadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 820.dp),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    // Top Bar: Top-Left Settings icon + City selector + Refresh
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconButton(
                            onClick = { showSettingsDialog = true },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("weather_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Settings,
                                contentDescription = "Settings",
                                tint = MaterialTheme.colorScheme.onBackground
                            )
                        }

                        Surface(
                            onClick = { showCityPicker = true },
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier
                                .weight(1f, fill = false)
                                .padding(horizontal = 8.dp)
                                .testTag("weather_city_picker_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.LocationOn,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = selectedLocation.name,
                                    style = MaterialTheme.typography.titleSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        IconButton(
                            onClick = onRefresh,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("weather_refresh_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Refresh,
                                contentDescription = "Refresh weather",
                                tint = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                }

                when (uiState) {
                    is WeatherUiState.Loading -> {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(24.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(48.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    CircularProgressIndicator()
                                    Text(
                                        text = "Loading forecast for ${selectedLocation.name}...",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    is WeatherUiState.Error -> {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(22.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Cloud,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.secondary,
                                        modifier = Modifier.size(44.dp)
                                    )
                                    Text(
                                        text = "Forecast Unavailable",
                                        style = MaterialTheme.typography.titleLarge
                                    )
                                    Text(
                                        text = uiState.message,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Button(onClick = onRefresh, shape = RoundedCornerShape(12.dp)) {
                                        Text("Retry")
                                    }
                                }
                            }
                        }
                    }

                    is WeatherUiState.Success -> {
                        val forecast = uiState.forecast
                        item {
                            CurrentWeatherHeroCard(
                                forecast = forecast,
                                useFahrenheit = useFahrenheit
                            )
                        }

                        item {
                            WeatherMetricsRow(
                                forecast = forecast,
                                useFahrenheit = useFahrenheit
                            )
                        }

                        if (forecast.hourly.isNotEmpty()) {
                            item {
                                Text(
                                    text = "Hourly Forecast",
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                            item {
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    items(forecast.hourly) { point ->
                                        HourlyForecastChip(
                                            point = point,
                                            useFahrenheit = useFahrenheit,
                                            isDay = forecast.isDay
                                        )
                                    }
                                }
                            }
                        }

                        if (forecast.daily.isNotEmpty()) {
                            item {
                                Text(
                                    text = "7-Day Forecast",
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(20.dp),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        val globalMin = forecast.daily.minOf { it.minTempCelsius }
                                        val globalMax = forecast.daily.maxOf { it.maxTempCelsius }
                                        forecast.daily.forEachIndexed { idx, day ->
                                            DailyForecastRow(
                                                point = day,
                                                globalMin = globalMin,
                                                globalMax = globalMax,
                                                useFahrenheit = useFahrenheit
                                            )
                                            if (idx < forecast.daily.lastIndex) {
                                                HorizontalDivider(
                                                    modifier = Modifier.padding(vertical = 10.dp),
                                                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSettingsDialog) {
        WeatherSettingsPromoDialog(
            useFahrenheit = useFahrenheit,
            onToggleFahrenheit = onToggleFahrenheit,
            onDismiss = { showSettingsDialog = false },
            onSubmitPromoCode = { code ->
                val unlocked = onPromoCodeSubmit(code)
                if (unlocked) {
                    showSettingsDialog = false
                }
                unlocked
            }
        )
    }

    if (showCityPicker) {
        CityPickerDialog(
            cityResults = cityResults,
            onSearch = onSearchCities,
            onSelectCity = { loc ->
                onSelectLocation(loc)
                showCityPicker = false
            },
            onDismiss = { showCityPicker = false }
        )
    }
}

@Composable
private fun CurrentWeatherHeroCard(
    forecast: WeatherForecast,
    useFahrenheit: Boolean
) {
    val condition = WeatherCondition.fromWmoCode(forecast.weatherCode)
    val today = forecast.daily.firstOrNull()
    val gradientColors = if (forecast.isDay) {
        listOf(Color(0xFF0E2B4B), Color(0xFF1D4ED8), Color(0xFF38BDF8))
    } else {
        listOf(Color(0xFF091529), Color(0xFF172554), Color(0xFF1E3A8A))
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.linearGradient(gradientColors))
                .padding(22.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = forecast.location.name,
                            style = MaterialTheme.typography.headlineSmall,
                            color = Color.White
                        )
                        if (forecast.location.region.isNotBlank()) {
                            Text(
                                text = forecast.location.region,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.8f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Icon(
                        imageVector = weatherIconFor(forecast.weatherCode, forecast.isDay),
                        contentDescription = condition.label,
                        tint = weatherTintFor(forecast.weatherCode, forecast.isDay),
                        modifier = Modifier.size(56.dp)
                    )
                }

                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = WeatherViewModel.formatTemp(forecast.currentTempCelsius, useFahrenheit),
                        fontSize = 62.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Column(modifier = Modifier.padding(bottom = 10.dp)) {
                        Text(
                            text = condition.label,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White
                        )
                        if (today != null) {
                            Text(
                                text = "H: ${WeatherViewModel.formatTemp(today.maxTempCelsius, useFahrenheit)}  •  L: ${WeatherViewModel.formatTemp(today.minTempCelsius, useFahrenheit)}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                        }
                    }
                }

                if (forecast.isFromCache) {
                    Text(
                        text = "Showing last cached forecast (offline)",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.75f)
                    )
                }
            }
        }
    }
}

@Composable
private fun WeatherMetricsRow(
    forecast: WeatherForecast,
    useFahrenheit: Boolean
) {
    val precip = forecast.daily.firstOrNull()?.precipProbability ?: 0
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        MetricTile(
            icon = Icons.Filled.Thermostat,
            label = "Feels Like",
            value = WeatherViewModel.formatTemp(forecast.apparentTempCelsius, useFahrenheit),
            modifier = Modifier.weight(1f)
        )
        MetricTile(
            icon = Icons.Filled.WaterDrop,
            label = "Humidity",
            value = "${forecast.humidityPercent}%",
            modifier = Modifier.weight(1f)
        )
        MetricTile(
            icon = Icons.Filled.Air,
            label = "Wind",
            value = "${forecast.windSpeedKmh.roundToInt()} km/h",
            modifier = Modifier.weight(1f)
        )
        MetricTile(
            icon = Icons.Filled.Thunderstorm,
            label = "Rain",
            value = "$precip%",
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun MetricTile(
    icon: ImageVector,
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1
            )
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun HourlyForecastChip(
    point: HourlyForecastPoint,
    useFahrenheit: Boolean,
    isDay: Boolean
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = point.timeLabel,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Icon(
                imageVector = weatherIconFor(point.weatherCode, isDay),
                contentDescription = null,
                tint = weatherTintFor(point.weatherCode, isDay),
                modifier = Modifier.size(22.dp)
            )
            Text(
                text = WeatherViewModel.formatTemp(point.tempCelsius, useFahrenheit),
                style = MaterialTheme.typography.titleSmall
            )
        }
    }
}

@Composable
private fun DailyForecastRow(
    point: DailyForecastPoint,
    globalMin: Double,
    globalMax: Double,
    useFahrenheit: Boolean
) {
    val span = (globalMax - globalMin).coerceAtLeast(1.0)
    val startFraction = ((point.minTempCelsius - globalMin) / span).toFloat().coerceIn(0f, 1f)
    val endFraction = ((point.maxTempCelsius - globalMin) / span).toFloat().coerceIn(startFraction, 1f)

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = point.dayLabel,
            style = MaterialTheme.typography.titleSmall,
            modifier = Modifier.width(56.dp)
        )

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.width(64.dp)
        ) {
            Icon(
                imageVector = weatherIconFor(point.weatherCode, true),
                contentDescription = null,
                tint = weatherTintFor(point.weatherCode, true),
                modifier = Modifier.size(20.dp)
            )
            if (point.precipProbability > 0) {
                Text(
                    text = "${point.precipProbability}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }

        Text(
            text = WeatherViewModel.formatTemp(point.minTempCelsius, useFahrenheit),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(34.dp)
        )

        Box(
            modifier = Modifier
                .weight(1f)
                .height(6.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
        ) {
            Row(modifier = Modifier.fillMaxSize()) {
                if (startFraction > 0f) {
                    Spacer(modifier = Modifier.weight(startFraction))
                }
                Box(
                    modifier = Modifier
                        .weight((endFraction - startFraction).coerceAtLeast(0.08f))
                        .fillMaxSize()
                        .clip(CircleShape)
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color(0xFF38BDF8), Color(0xFFFBBF24))
                            )
                        )
                )
                val trail = (1f - endFraction).coerceAtLeast(0f)
                if (trail > 0f) {
                    Spacer(modifier = Modifier.weight(trail))
                }
            }
        }

        Text(
            text = WeatherViewModel.formatTemp(point.maxTempCelsius, useFahrenheit),
            style = MaterialTheme.typography.titleSmall,
            modifier = Modifier.width(34.dp)
        )
    }
}

@Composable
private fun WeatherSettingsPromoDialog(
    useFahrenheit: Boolean,
    onToggleFahrenheit: (Boolean) -> Unit,
    onDismiss: () -> Unit,
    onSubmitPromoCode: (String) -> Boolean
) {
    var promoCode by remember { mutableStateOf("") }
    var showInvalidError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Weather Settings") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Use Fahrenheit (°F)", style = MaterialTheme.typography.bodyLarge)
                        Text(
                            "Switch between °C and °F",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = useFahrenheit,
                        onCheckedChange = onToggleFahrenheit
                    )
                }

                HorizontalDivider()

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Promo Code", style = MaterialTheme.typography.titleSmall)
                    OutlinedTextField(
                        value = promoCode,
                        onValueChange = {
                            promoCode = it
                            showInvalidError = false
                        },
                        label = { Text("Enter promo code") },
                        singleLine = true,
                        isError = showInvalidError,
                        supportingText = if (showInvalidError) {
                            { Text("Invalid promo code. Please try again.") }
                        } else null,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                if (!onSubmitPromoCode(promoCode)) {
                                    showInvalidError = true
                                }
                            }
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("promo_code_input"),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (!onSubmitPromoCode(promoCode)) {
                        showInvalidError = true
                    }
                },
                modifier = Modifier.testTag("apply_promo_code_button")
            ) {
                Text("Apply")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
private fun CityPickerDialog(
    cityResults: List<WeatherLocation>,
    onSearch: (String) -> Unit,
    onSelectCity: (WeatherLocation) -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Select Location") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = {
                        query = it
                        onSearch(it)
                    },
                    placeholder = { Text("Search city...") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
                LazyColumn(
                    modifier = Modifier.height(240.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(cityResults) { loc ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerLow,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectCity(loc) }
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(loc.name, style = MaterialTheme.typography.titleSmall)
                                if (loc.region.isNotBlank()) {
                                    Text(
                                        loc.region,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

private fun weatherIconFor(code: Int, isDay: Boolean): ImageVector {
    return when (WeatherCondition.fromWmoCode(code)) {
        WeatherCondition.CLEAR -> if (isDay) Icons.Filled.WbSunny else Icons.Filled.NightsStay
        WeatherCondition.PARTLY_CLOUDY,
        WeatherCondition.OVERCAST,
        WeatherCondition.FOG -> Icons.Filled.Cloud
        WeatherCondition.DRIZZLE,
        WeatherCondition.RAIN -> Icons.Filled.WaterDrop
        WeatherCondition.SNOW -> Icons.Filled.AcUnit
        WeatherCondition.THUNDERSTORM -> Icons.Filled.Thunderstorm
    }
}

private fun weatherTintFor(code: Int, isDay: Boolean): Color {
    return when (WeatherCondition.fromWmoCode(code)) {
        WeatherCondition.CLEAR -> if (isDay) Color(0xFFFBBF24) else Color(0xFF93C5FD)
        WeatherCondition.PARTLY_CLOUDY -> Color(0xFFBAE6FD)
        WeatherCondition.OVERCAST,
        WeatherCondition.FOG -> Color(0xFFCBD5E1)
        WeatherCondition.DRIZZLE,
        WeatherCondition.RAIN -> Color(0xFF38BDF8)
        WeatherCondition.SNOW -> Color(0xFFE0F2FE)
        WeatherCondition.THUNDERSTORM -> Color(0xFFFACC15)
    }
}
