package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val VaultDarkColorScheme = darkColorScheme(
    primary = CyberMint,
    onPrimary = OnCyberMint,
    primaryContainer = CyberMintContainer,
    onPrimaryContainer = OnCyberMintContainer,
    secondary = CyberCobalt,
    onSecondary = OnCyberCobalt,
    secondaryContainer = CyberCobaltContainer,
    onSecondaryContainer = OnCyberCobaltContainer,
    tertiary = AmberShield,
    onTertiary = OnAmberShield,
    tertiaryContainer = AmberShieldContainer,
    onTertiaryContainer = OnAmberShieldContainer,
    error = DangerCrimson,
    onError = OnDangerCrimson,
    errorContainer = DangerContainer,
    onErrorContainer = OnDangerContainer,
    background = ObsidianBg,
    onBackground = TextPrimaryDark,
    surface = SlateSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = SlateContainer,
    onSurfaceVariant = TextSecondaryDark,
    surfaceContainerLowest = ObsidianBg,
    surfaceContainerLow = SlateSurfaceLow,
    surfaceContainer = SlateContainer,
    surfaceContainerHigh = SlateContainerHigh,
    outline = SlateOutline,
    outlineVariant = SlateOutlineVariant
)

private val VaultLightColorScheme = lightColorScheme(
    primary = EmeraldPrimary,
    onPrimary = PureSurface,
    primaryContainer = EmeraldContainer,
    onPrimaryContainer = OnEmeraldContainer,
    secondary = CobaltSecondary,
    onSecondary = PureSurface,
    secondaryContainer = CobaltContainer,
    onSecondaryContainer = OnCobaltContainer,
    tertiary = AmberTertiary,
    onTertiary = PureSurface,
    tertiaryContainer = AmberContainer,
    onTertiaryContainer = OnAmberContainer,
    background = AlabasterBg,
    onBackground = TextPrimaryLight,
    surface = PureSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = CoolContainer,
    onSurfaceVariant = TextSecondaryLight,
    surfaceContainerLowest = PureSurface,
    surfaceContainerLow = AlabasterBg,
    surfaceContainer = CoolContainer,
    surfaceContainerHigh = CoolContainerHigh,
    outline = CoolOutline,
    outlineVariant = CoolOutlineVariant
)

@Composable
fun VaultBoxTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) VaultDarkColorScheme else VaultLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
