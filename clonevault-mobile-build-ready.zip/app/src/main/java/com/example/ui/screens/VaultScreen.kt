package com.example.ui.screens

import android.graphics.drawable.Drawable
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.ClonedAppEntity
import com.example.data.ClonedAppStatus
import com.example.ui.VaultFilter
import com.example.ui.components.ClonedAppCard
import com.example.ui.components.DualEnvironmentHeroCard

@Composable
fun VaultScreen(
    allClones: List<ClonedAppStatus>,
    filteredClones: List<ClonedAppStatus>,
    selectedFilter: VaultFilter,
    onFilterSelected: (VaultFilter) -> Unit,
    onRefreshStatuses: () -> Unit,
    onOpenCloneLab: () -> Unit,
    onImportApkClick: () -> Unit,
    onLearnArchitecture: () -> Unit,
    onOpenCloneDetails: (Long) -> Unit,
    onLaunchClone: (ClonedAppEntity) -> Unit,
    onExportClone: (ClonedAppEntity) -> Unit,
    onLockToWeather: () -> Unit,
    loadAppIcon: (String) -> Drawable?,
    modifier: Modifier = Modifier
) {
    val mainUninstalledCount = remember(allClones) {
        allClones.count { !it.isMainAppInstalledOutside }
    }
    val runnableCount = remember(allClones) {
        allClones.count { it.isRunnableIndependently }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 840.dp),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 104.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Shield,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                    Column {
                        Text(
                            text = "VaultBox",
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "APK Sandbox & Independent Cloner",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onLockToWeather,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("lock_to_weather_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.WbSunny,
                            contentDescription = "Return to Weather",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(
                        onClick = onRefreshStatuses,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("refresh_vault_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "Verify outside and sandboxed app statuses",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }

        item {
            DualEnvironmentHeroCard(
                totalClones = allClones.size,
                mainUninstalledCount = mainUninstalledCount,
                runnableClonesCount = runnableCount,
                onLearnArchitecture = onLearnArchitecture
            )
        }

        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(VaultFilter.entries) { filter ->
                    val selected = filter == selectedFilter
                    FilterChip(
                        selected = selected,
                        onClick = { onFilterSelected(filter) },
                        label = {
                            Text(
                                text = filter.label,
                                style = MaterialTheme.typography.labelLarge
                            )
                        },
                        modifier = Modifier.testTag("vault_filter_${filter.name.lowercase()}"),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    )
                }
            }
        }

        if (filteredClones.isEmpty()) {
            item {
                VaultEmptyState(
                    hasAnyClones = allClones.isNotEmpty(),
                    onOpenCloneLab = onOpenCloneLab,
                    onImportApkClick = onImportApkClick
                )
            }
        } else {
            items(filteredClones, key = { it.entity.id }) { status ->
                val icon = remember(status.entity.originalPackageName, status.entity.clonedPackageName) {
                    loadAppIcon(status.entity.clonedPackageName)
                        ?: loadAppIcon(status.entity.originalPackageName)
                }
                ClonedAppCard(
                    status = status,
                    iconDrawable = icon,
                    onOpenDetails = { onOpenCloneDetails(status.entity.id) },
                    onLaunchClone = { onLaunchClone(status.entity) },
                    onExportApk = { onExportClone(status.entity) }
                )
            }
        }
    }
}

@Composable
private fun VaultEmptyState(
    hasAnyClones: Boolean,
    onOpenCloneLab: () -> Unit,
    onImportApkClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Layers,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(44.dp)
            )
            Text(
                text = if (hasAnyClones) "No Clones Match Filter" else "Your Sandbox Vault Is Empty",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = if (hasAnyClones) {
                    "Switch filters above to view your other sandboxed APK containers."
                } else {
                    "Clone any installed app or import an .apk file to isolate it inside VaultBox. Even if you uninstall the main app outside, your cloned app stays preserved and independent."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onOpenCloneLab,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("empty_clone_installed_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Add,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Clone App")
                }

                OutlinedButton(
                    onClick = onImportApkClick,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("empty_import_apk_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.FolderOpen,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Import APK")
                }
            }
        }
    }
}
