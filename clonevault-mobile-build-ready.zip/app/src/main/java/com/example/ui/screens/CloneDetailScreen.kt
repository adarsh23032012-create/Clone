package com.example.ui.screens

import android.graphics.drawable.Drawable
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Launch
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.ClonedAppEntity
import com.example.data.ClonedAppStatus
import com.example.data.NetworkIsolationMode
import com.example.data.SandboxEventEntity
import com.example.ui.SandboxViewModel
import com.example.ui.components.AppIconThumbnail
import com.example.ui.theme.JetBrainsMonoFamily

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CloneDetailScreen(
    status: ClonedAppStatus?,
    events: List<SandboxEventEntity>,
    initialIsolatedNote: String,
    loadAppIcon: (String) -> Drawable?,
    onBack: () -> Unit,
    onVerifySurvival: (ClonedAppEntity) -> Unit,
    onLaunchClone: (ClonedAppEntity) -> Unit,
    onExportApk: (ClonedAppEntity) -> Unit,
    onShareApk: (ClonedAppEntity) -> Unit,
    onUpdatePolicies: (ClonedAppEntity, Boolean, Boolean, Boolean, NetworkIsolationMode) -> Unit,
    onSaveIsolatedNote: (ClonedAppEntity, String) -> Unit,
    onDeleteClone: (ClonedAppEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showPermissions by remember { mutableStateOf(false) }
    var isolatedNote by remember(initialIsolatedNote) { mutableStateOf(initialIsolatedNote) }

    LaunchedEffect(initialIsolatedNote) {
        isolatedNote = initialIsolatedNote
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = status?.entity?.cloneLabel ?: "Sandbox Details",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("detail_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Navigate back"
                        )
                    }
                },
                actions = {
                    if (status != null) {
                        IconButton(
                            onClick = { showDeleteConfirm = true },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("delete_clone_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Delete,
                                contentDescription = "Delete sandbox",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        if (status == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        val entity = status.entity
        val icon = remember(entity.originalPackageName, entity.clonedPackageName) {
            loadAppIcon(entity.clonedPackageName) ?: loadAppIcon(entity.originalPackageName)
        }
        val permissions = remember(entity.permissionsList) {
            entity.permissionsList.split('\n').filter { it.isNotBlank() }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 840.dp),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header Identity Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppIconThumbnail(
                                appName = entity.cloneLabel,
                                iconDrawable = icon,
                                size = 60.dp
                            )
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(entity.cloneLabel, style = MaterialTheme.typography.titleLarge)
                                Text(
                                    text = entity.clonedPackageName,
                                    style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFamily),
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Version ${entity.versionName} (${entity.versionCode}) • ${SandboxViewModel.formatBytes(entity.apkSizeBytes)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // Dual-Environment Status Comparison
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        EnvironmentStatusCard(
                            title = "Main App (Outside)",
                            packageId = entity.originalPackageName,
                            statusLabel = if (status.isMainAppInstalledOutside) "INSTALLED" else "UNINSTALLED",
                            subtitle = if (status.isMainAppInstalledOutside) {
                                "Main copy active in personal space"
                            } else {
                                "Removed outside — clone remains safe"
                            },
                            isPositive = status.isMainAppInstalledOutside,
                            isAmberWarning = !status.isMainAppInstalledOutside,
                            modifier = Modifier.weight(1f)
                        )
                        EnvironmentStatusCard(
                            title = "Cloned App (Sandbox)",
                            packageId = entity.clonedPackageName,
                            statusLabel = when {
                                status.isRunnableIndependently -> "RUNNABLE"
                                status.clonedApkFileExists -> "VAULT READY"
                                else -> "SNAPSHOT"
                            },
                            subtitle = when {
                                status.isActiveInManagedProfile -> "Running inside Work Profile"
                                status.isClonePackageInstalled -> "Installed independently on device"
                                status.clonedApkFileExists -> "Signed APK archived in VaultBox"
                                else -> "Vault data preserved"
                            },
                            isPositive = status.survivesMainUninstall,
                            isAmberWarning = false,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Primary Actions
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { onLaunchClone(entity) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("launch_clone_detail_button"),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Launch,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (status.isRunnableIndependently) {
                                    "Launch Independent Cloned App"
                                } else {
                                    "Deploy / Launch Cloned App"
                                }
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { onVerifySurvival(entity) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("verify_survival_button"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.VerifiedUser,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Verify Survival", maxLines = 1)
                            }
                            OutlinedButton(
                                onClick = { onExportApk(entity) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("export_apk_detail_button"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.SaveAlt,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Export .APK", maxLines = 1)
                            }
                            OutlinedButton(
                                onClick = { onShareApk(entity) },
                                modifier = Modifier.testTag("share_apk_detail_button"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Share,
                                    contentDescription = "Share cloned APK",
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                // Sandbox Isolation Policies
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("Sandbox Isolation Policies", style = MaterialTheme.typography.titleMedium)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Isolate Container Storage", style = MaterialTheme.typography.bodyMedium)
                                    Text(
                                        "Decouple files & preferences from main app",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(
                                    checked = entity.isolateStorage,
                                    onCheckedChange = {
                                        onUpdatePolicies(
                                            entity,
                                            it,
                                            entity.isolateDeviceIds,
                                            entity.blockTrackers,
                                            entity.networkMode
                                        )
                                    }
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Virtualize Device Identifiers", style = MaterialTheme.typography.bodyMedium)
                                    Text(
                                        "Assign sandboxed SSAID & instance tokens",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(
                                    checked = entity.isolateDeviceIds,
                                    onCheckedChange = {
                                        onUpdatePolicies(
                                            entity,
                                            entity.isolateStorage,
                                            it,
                                            entity.blockTrackers,
                                            entity.networkMode
                                        )
                                    }
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Block Background Trackers", style = MaterialTheme.typography.bodyMedium)
                                    Text(
                                        "Restrict analytics & cross-app telemetry",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(
                                    checked = entity.blockTrackers,
                                    onCheckedChange = {
                                        onUpdatePolicies(
                                            entity,
                                            entity.isolateStorage,
                                            entity.isolateDeviceIds,
                                            it,
                                            entity.networkMode
                                        )
                                    }
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                NetworkIsolationMode.entries.forEach { mode ->
                                    FilterChip(
                                        selected = entity.networkMode == mode,
                                        onClick = {
                                            onUpdatePolicies(
                                                entity,
                                                entity.isolateStorage,
                                                entity.isolateDeviceIds,
                                                entity.blockTrackers,
                                                mode
                                            )
                                        },
                                        label = { Text(mode.label, style = MaterialTheme.typography.labelSmall) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }

                // Isolated Container Storage Workspace
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Isolated Container Data", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = SandboxViewModel.formatBytes(status.isolatedDataSizeBytes),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Text(
                                text = "Path: ${entity.isolatedDataDir}",
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            OutlinedTextField(
                                value = isolatedNote,
                                onValueChange = { isolatedNote = it },
                                label = { Text("Sandbox Container State / Notes") },
                                placeholder = { Text("Store isolated session notes inside this clone's private container...") },
                                minLines = 2,
                                maxLines = 4,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("isolated_note_input"),
                                shape = RoundedCornerShape(12.dp)
                            )
                            OutlinedButton(
                                onClick = { onSaveIsolatedNote(entity, isolatedNote) },
                                modifier = Modifier
                                    .align(Alignment.End)
                                    .testTag("save_isolated_note_button"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Save,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Save to Container")
                            }
                        }
                    }
                }

                // Binary Telemetry & Permissions
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Fingerprint,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary
                                )
                                Text("APK Binary & Signature Telemetry", style = MaterialTheme.typography.titleMedium)
                            }
                            TelemetryRow(
                                "Home Screen Visibility",
                                if (entity.hideFromLauncher) "Hidden (Vault-Only Launch)" else "Visible on Launcher"
                            )
                            if (entity.mainActivityClass.isNotBlank()) {
                                TelemetryRow("Entry Activity", entity.mainActivityClass.substringAfterLast('.'))
                            }
                            TelemetryRow("Manifest Patched", if (entity.manifestPatched) "AXML Package Re-identified" else "Snapshot Archive")
                            TelemetryRow("DEX / Native ABIs", "${entity.dexCount} DEX • ${entity.nativeAbis.ifBlank { "Universal" }}")
                            TelemetryRow("SDK Range", "minSdk ${entity.minSdk} -> targetSdk ${entity.targetSdk}")
                            TelemetryRow("Origin Cert SHA-256", entity.signingSha256.take(32) + "…")
                            TelemetryRow("Clone v2 Cert SHA-256", entity.cloneSigningSha256.take(32) + "…")

                            Spacer(modifier = Modifier.height(2.dp))
                            OutlinedButton(
                                onClick = { showPermissions = !showPermissions },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Declared Permissions (${permissions.size})")
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = if (showPermissions) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                                    contentDescription = null
                                )
                            }
                            AnimatedVisibility(visible = showPermissions) {
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    if (permissions.isEmpty()) {
                                        Text(
                                            "No permissions declared.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    } else {
                                        permissions.forEach { perm ->
                                            Text(
                                                text = perm,
                                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Event History
                if (events.isNotEmpty()) {
                    item {
                        Text("Container Event Log", style = MaterialTheme.typography.titleMedium)
                    }
                    items(events, key = { it.id }) { ev ->
                        EventLogRow(event = ev)
                    }
                }
            }
        }
    }

    if (showDeleteConfirm && status != null) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete Sandbox Container?") },
            text = {
                Text("This will remove ${status.entity.cloneLabel}, its archived APK snapshot, and its isolated container data from VaultBox.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDeleteClone(status.entity)
                        onBack()
                    }
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun EnvironmentStatusCard(
    title: String,
    packageId: String,
    statusLabel: String,
    subtitle: String,
    isPositive: Boolean,
    isAmberWarning: Boolean,
    modifier: Modifier = Modifier
) {
    val containerColor = when {
        isAmberWarning -> MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.45f)
        isPositive -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
        else -> MaterialTheme.colorScheme.surfaceContainer
    }
    val accent = when {
        isAmberWarning -> MaterialTheme.colorScheme.tertiary
        isPositive -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.secondary
    }

    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.45f)),
        colors = CardDefaults.cardColors(containerColor = containerColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = when {
                        isAmberWarning -> Icons.Filled.CloudOff
                        isPositive -> Icons.Filled.CheckCircle
                        else -> Icons.Filled.Lock
                    },
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = statusLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = accent
                )
            }
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(
                text = packageId,
                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun TelemetryRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
