package com.example.profile

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.os.Build
import android.os.Process
import android.os.UserHandle
import android.os.UserManager

data class UserProfileDescriptor(
    val userHandle: UserHandle,
    val profileId: Int,
    val isCurrentProfile: Boolean,
    val isManagedProfile: Boolean,
    val label: String,
    val installedAppCount: Int,
    val packages: List<String>
)

data class ManagedProfileState(
    val isProfileOwner: Boolean,
    val isProvisioningAllowed: Boolean,
    val currentUserId: Int,
    val profiles: List<UserProfileDescriptor>,
    val hasSecondaryProfile: Boolean
)

class ManagedProfileManager(private val context: Context) {

    private val userManager = context.getSystemService(Context.USER_SERVICE) as? UserManager
    private val devicePolicyManager =
        context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
    private val launcherApps =
        context.getSystemService(Context.LAUNCHER_APPS_SERVICE) as? LauncherApps

    fun inspectProfiles(): ManagedProfileState {
        val currentHandle = Process.myUserHandle()
        val currentId = extractUserId(currentHandle)
        val isProfileOwner = runCatching {
            devicePolicyManager?.isProfileOwnerApp(context.packageName) == true
        }.getOrDefault(false)

        val provisioningAllowed = runCatching {
            devicePolicyManager?.isProvisioningAllowed(
                DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE
            ) == true
        }.getOrDefault(false)

        val handles = runCatching { userManager?.userProfiles ?: listOf(currentHandle) }
            .getOrDefault(listOf(currentHandle))

        val descriptors = handles.map { handle ->
            val id = extractUserId(handle)
            val isCurrent = handle == currentHandle
            val activities = runCatching {
                launcherApps?.getActivityList(null, handle).orEmpty()
            }.getOrDefault(emptyList())
            val pkgs = activities.map { it.applicationInfo.packageName }.distinct().sorted()
            val managed = !isCurrent && (id >= 10 || isProfileOwner)
            val label = when {
                isCurrent && isProfileOwner -> "VaultBox Sandbox Profile (User $id)"
                isCurrent -> "Primary Personal Space (User $id)"
                else -> "Isolated Secondary Profile (User $id)"
            }
            UserProfileDescriptor(
                userHandle = handle,
                profileId = id,
                isCurrentProfile = isCurrent,
                isManagedProfile = managed,
                label = label,
                installedAppCount = pkgs.size,
                packages = pkgs
            )
        }

        return ManagedProfileState(
            isProfileOwner = isProfileOwner,
            isProvisioningAllowed = provisioningAllowed,
            currentUserId = currentId,
            profiles = descriptors,
            hasSecondaryProfile = descriptors.any { !it.isCurrentProfile }
        )
    }

    fun buildProvisionManagedProfileIntent(): Intent {
        val adminComponent = ComponentName(context, SandboxAdminReceiver::class.java)
        return Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE).apply {
            putExtra(DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME, adminComponent)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                putExtra(DevicePolicyManager.EXTRA_PROVISIONING_SKIP_ENCRYPTION, false)
            }
        }
    }

    fun isPackageInSecondaryProfile(packageName: String): Boolean {
        val currentHandle = Process.myUserHandle()
        val handles = runCatching { userManager?.userProfiles.orEmpty() }.getOrDefault(emptyList())
        return handles.filter { it != currentHandle }.any { handle ->
            runCatching {
                launcherApps?.getActivityList(packageName, handle)?.isNotEmpty() == true
            }.getOrDefault(false)
        }
    }

    fun launchPackageInSecondaryProfile(packageName: String): Boolean {
        val currentHandle = Process.myUserHandle()
        val handles = runCatching { userManager?.userProfiles.orEmpty() }.getOrDefault(emptyList())
        for (handle in handles.filter { it != currentHandle }) {
            val activity = runCatching {
                launcherApps?.getActivityList(packageName, handle)?.firstOrNull()
            }.getOrNull() ?: continue
            val launched = runCatching {
                launcherApps?.startMainActivity(activity.componentName, handle, null, null)
                true
            }.getOrDefault(false)
            if (launched) return true
        }
        return false
    }

    private fun extractUserId(handle: UserHandle): Int {
        // UserHandle.toString() format on Android is "UserHandle{0}" or "UserHandle{10}"
        val raw = handle.toString()
        val digits = raw.substringAfter('{', "").substringBefore('}', "")
        return digits.toIntOrNull() ?: handle.hashCode()
    }
}
