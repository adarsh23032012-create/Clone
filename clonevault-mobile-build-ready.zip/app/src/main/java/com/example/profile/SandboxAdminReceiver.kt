package com.example.profile

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log

class SandboxAdminReceiver : DeviceAdminReceiver() {
    override fun onProfileProvisioningComplete(context: Context, intent: Intent) {
        super.onProfileProvisioningComplete(context, intent)
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
        val adminComponent = ComponentName(context, SandboxAdminReceiver::class.java)
        try {
            dpm?.setProfileName(adminComponent, "VaultBox Sandbox")
            dpm?.setProfileEnabled(adminComponent)
        } catch (e: SecurityException) {
            Log.w("SandboxAdminReceiver", "Unable to finalize profile setup", e)
        }
    }
}
