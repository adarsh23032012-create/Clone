package com.example.engine

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.ZipFile

data class InstalledAppItem(
    val appName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val sourceApkPath: String,
    val apkSizeBytes: Long,
    val minSdk: Int,
    val targetSdk: Int,
    val isSystemApp: Boolean,
    val hasSplitApks: Boolean,
    val mainActivityClass: String = ""
)

data class InspectedApkInfo(
    val appName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val minSdk: Int,
    val targetSdk: Int,
    val apkSizeBytes: Long,
    val dexCount: Int,
    val nativeAbis: List<String>,
    val permissions: List<String>,
    val signingSha256: String,
    val tempOrSourcePath: String,
    val isFromUriImport: Boolean,
    val hasSplitApks: Boolean,
    val mainActivityClass: String = ""
)

class ApkInspectorEngine(private val context: Context) {

    private val pm: PackageManager = context.packageManager

    fun discoverLaunchableApps(): List<InstalledAppItem> {
        val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(
                launcherIntent,
                PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL.toLong())
            )
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(launcherIntent, 0)
        }

        val seenPackages = HashSet<String>()
        val results = mutableListOf<InstalledAppItem>()

        for (ri in resolveInfos) {
            val pkg = ri.activityInfo?.packageName ?: continue
            if (!seenPackages.add(pkg)) continue
            if (pkg == context.packageName) continue

            val pkgInfo = getInstalledPackageInfo(pkg) ?: continue
            val appInfo = pkgInfo.applicationInfo ?: continue
            val sourceDir = appInfo.sourceDir ?: continue
            val apkFile = File(sourceDir)
            val sizeBytes = if (apkFile.exists()) apkFile.length() else 0L
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val label = runCatching { appInfo.loadLabel(pm).toString() }
                .getOrDefault(pkg.substringAfterLast('.'))

            results.add(
                InstalledAppItem(
                    appName = label,
                    packageName = pkg,
                    versionName = pkgInfo.versionName ?: "1.0",
                    versionCode = extractVersionCode(pkgInfo),
                    sourceApkPath = sourceDir,
                    apkSizeBytes = sizeBytes,
                    minSdk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) appInfo.minSdkVersion else 24,
                    targetSdk = appInfo.targetSdkVersion,
                    isSystemApp = isSystem,
                    hasSplitApks = !appInfo.splitSourceDirs.isNullOrEmpty(),
                    mainActivityClass = ri.activityInfo?.name.orEmpty()
                )
            )
        }

        return results.sortedWith(
            compareBy<InstalledAppItem> { it.isSystemApp }.thenBy { it.appName.lowercase() }
        )
    }

    fun loadAppIcon(packageName: String): Drawable? {
        return runCatching { pm.getApplicationIcon(packageName) }.getOrNull()
    }

    fun isPackageInstalled(packageName: String): Boolean {
        return getInstalledPackageInfo(packageName) != null
    }

    fun getLaunchIntent(packageName: String, mainActivityClass: String = ""): Intent? {
        pm.getLaunchIntentForPackage(packageName)?.let { return it }

        val hiddenIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(AxmlPackagePatcher.SANDBOX_HIDDEN_CATEGORY)
            setPackage(packageName)
        }
        val hiddenResolve = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(
                hiddenIntent,
                PackageManager.ResolveInfoFlags.of(0)
            )
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(hiddenIntent, 0)
        }.firstOrNull()

        if (hiddenResolve?.activityInfo != null) {
            return Intent(Intent.ACTION_MAIN).apply {
                addCategory(AxmlPackagePatcher.SANDBOX_HIDDEN_CATEGORY)
                setClassName(hiddenResolve.activityInfo.packageName, hiddenResolve.activityInfo.name)
            }
        }

        if (isPackageInstalled(packageName) && mainActivityClass.isNotBlank()) {
            return Intent(Intent.ACTION_MAIN).apply {
                addCategory(AxmlPackagePatcher.SANDBOX_HIDDEN_CATEGORY)
                setClassName(packageName, mainActivityClass)
            }
        }
        return null
    }

    fun inspectInstalledApp(item: InstalledAppItem): InspectedApkInfo? {
        val file = File(item.sourceApkPath)
        if (!file.exists()) return null
        return inspectApkFile(
            apkFile = file,
            fallbackName = item.appName,
            isFromUriImport = false,
            hasSplitApks = item.hasSplitApks,
            knownMainActivity = item.mainActivityClass
        )
    }

    fun inspectApkFromUri(uri: Uri): InspectedApkInfo? {
        val importDir = File(context.cacheDir, "apk_imports").apply { mkdirs() }
        val tempFile = File(importDir, "import_${System.currentTimeMillis()}.apk")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(tempFile).use { output ->
                input.copyTo(output)
            }
        } ?: return null

        if (!tempFile.exists() || tempFile.length() == 0L) return null
        return inspectApkFile(
            apkFile = tempFile,
            fallbackName = tempFile.nameWithoutExtension,
            isFromUriImport = true,
            hasSplitApks = false
        )
    }

    fun inspectApkFile(
        apkFile: File,
        fallbackName: String,
        isFromUriImport: Boolean,
        hasSplitApks: Boolean,
        knownMainActivity: String = ""
    ): InspectedApkInfo? {
        if (!apkFile.exists()) return null

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            PackageManager.GET_PERMISSIONS or PackageManager.GET_ACTIVITIES or PackageManager.GET_SIGNING_CERTIFICATES
        } else {
            @Suppress("DEPRECATION")
            PackageManager.GET_PERMISSIONS or PackageManager.GET_ACTIVITIES or PackageManager.GET_SIGNATURES
        }

        val archiveInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getPackageArchiveInfo(
                apkFile.absolutePath,
                PackageManager.PackageInfoFlags.of(flags.toLong())
            )
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageArchiveInfo(apkFile.absolutePath, flags)
        } ?: return null

        val appInfo = archiveInfo.applicationInfo
        appInfo?.sourceDir = apkFile.absolutePath
        appInfo?.publicSourceDir = apkFile.absolutePath

        val appName = runCatching {
            appInfo?.loadLabel(pm)?.toString()?.takeIf { it.isNotBlank() }
        }.getOrNull() ?: fallbackName

        val permissions = archiveInfo.requestedPermissions?.toList().orEmpty().sorted()
        val signingHash = extractSigningSha256(archiveInfo) ?: computeFileSha256(apkFile)

        var dexCount = 0
        val abis = sortedSetOf<String>()
        runCatching {
            ZipFile(apkFile).use { zip ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val name = entries.nextElement().name
                    if (name.startsWith("classes") && name.endsWith(".dex")) {
                        dexCount++
                    } else if (name.startsWith("lib/") && name.endsWith(".so")) {
                        val abi = name.removePrefix("lib/").substringBefore('/')
                        if (abi.isNotBlank()) abis.add(abi)
                    }
                }
            }
        }

        return InspectedApkInfo(
            appName = appName,
            packageName = archiveInfo.packageName,
            versionName = archiveInfo.versionName ?: "1.0",
            versionCode = extractVersionCode(archiveInfo),
            minSdk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                appInfo?.minSdkVersion ?: 24
            } else 24,
            targetSdk = appInfo?.targetSdkVersion ?: 34,
            apkSizeBytes = apkFile.length(),
            dexCount = dexCount.coerceAtLeast(1),
            nativeAbis = abis.toList(),
            permissions = permissions,
            signingSha256 = signingHash,
            tempOrSourcePath = apkFile.absolutePath,
            isFromUriImport = isFromUriImport,
            hasSplitApks = hasSplitApks,
            mainActivityClass = knownMainActivity.ifBlank {
                archiveInfo.activities?.firstOrNull()?.name.orEmpty()
            }
        )
    }

    private fun getInstalledPackageInfo(packageName: String): PackageInfo? {
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(packageName, 0)
            }
        }.getOrNull()
    }

    private fun extractVersionCode(info: PackageInfo): Long {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            info.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            info.versionCode.toLong()
        }
    }

    private fun extractSigningSha256(info: PackageInfo): String? {
        val certBytes: ByteArray? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            info.signingInfo?.apkContentsSigners?.firstOrNull()?.toByteArray()
                ?: info.signingInfo?.signingCertificateHistory?.firstOrNull()?.toByteArray()
        } else {
            @Suppress("DEPRECATION")
            info.signatures?.firstOrNull()?.toByteArray()
        }
        return certBytes?.let { sha256Hex(it) }
    }

    companion object {
        fun computeFileSha256(file: File): String {
            val digest = MessageDigest.getInstance("SHA-256")
            file.inputStream().use { input ->
                val buf = ByteArray(16 * 1024)
                var read = input.read(buf)
                while (read != -1) {
                    digest.update(buf, 0, read)
                    read = input.read(buf)
                }
            }
            return digest.digest().joinToString("") { "%02x".format(it) }
        }

        fun sha256Hex(bytes: ByteArray): String {
            return MessageDigest.getInstance("SHA-256")
                .digest(bytes)
                .joinToString("") { "%02x".format(it) }
        }
    }
}
