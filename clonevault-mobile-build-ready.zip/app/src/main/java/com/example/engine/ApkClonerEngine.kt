package com.example.engine

import android.content.Context
import com.example.data.ClonedAppEntity
import com.example.data.IsolationMode
import com.example.data.NetworkIsolationMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.FilterOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

data class CloneBuildConfig(
    val inspectedApk: InspectedApkInfo,
    val cloneLabel: String,
    val clonedPackageName: String,
    val isolationMode: IsolationMode,
    val isolateStorage: Boolean,
    val isolateDeviceIds: Boolean,
    val blockTrackers: Boolean,
    val networkMode: NetworkIsolationMode,
    val hideFromLauncher: Boolean = true
)

data class CloneBuildProgress(
    val stepIndex: Int,
    val totalSteps: Int,
    val statusMessage: String
)

private class CountingOutputStream(out: OutputStream) : FilterOutputStream(out) {
    var bytesWritten: Long = 0L
        private set

    override fun write(b: Int) {
        out.write(b)
        bytesWritten++
    }

    override fun write(b: ByteArray, off: Int, len: Int) {
        out.write(b, off, len)
        bytesWritten += len
    }
}

class ApkClonerEngine(private val context: Context) {

    suspend fun buildClonedSandbox(
        config: CloneBuildConfig,
        onProgress: (CloneBuildProgress) -> Unit
    ): ClonedAppEntity = withContext(Dispatchers.IO) {
        val cloneUuid = UUID.randomUUID().toString().take(8)
        val vaultDir = File(context.filesDir, "sandbox_vault/$cloneUuid").apply { mkdirs() }
        val dataDir = File(context.filesDir, "sandbox_data/$cloneUuid").apply { mkdirs() }
        val keystoreDir = File(context.filesDir, "sandbox_keystore").apply { mkdirs() }

        // Step 1: Copy source APK snapshot into private vault so it survives main app uninstall
        onProgress(CloneBuildProgress(1, 5, "Archiving source APK into private sandbox vault..."))
        val sourceFile = File(config.inspectedApk.tempOrSourcePath)
        val snapshotApk = File(vaultDir, "source.apk")
        sourceFile.inputStream().use { input ->
            FileOutputStream(snapshotApk).use { output ->
                input.copyTo(output)
            }
        }
        if (config.inspectedApk.isFromUriImport) {
            runCatching { sourceFile.delete() }
        }

        // Step 2: Provision isolated per-clone filesystem structure
        onProgress(CloneBuildProgress(2, 5, "Provisioning isolated container data directory..."))
        File(dataDir, "files").mkdirs()
        File(dataDir, "shared_prefs").mkdirs()
        File(dataDir, "cache").mkdirs()
        val manifestJson = """
            {
              "cloneUuid": "$cloneUuid",
              "originalPackage": "${config.inspectedApk.packageName}",
              "clonedPackage": "${config.clonedPackageName}",
              "mainActivityClass": "${config.inspectedApk.mainActivityClass}",
              "hideFromLauncher": ${config.hideFromLauncher},
              "isolationMode": "${config.isolationMode.name}",
              "isolateStorage": ${config.isolateStorage},
              "isolateDeviceIds": ${config.isolateDeviceIds},
              "blockTrackers": ${config.blockTrackers},
              "networkMode": "${config.networkMode.name}",
              "createdAt": ${System.currentTimeMillis()}
            }
        """.trimIndent()
        File(dataDir, "sandbox_manifest.json").writeText(manifestJson)

        // Step 3: Patch binary AndroidManifest.xml (AXML) and rebuild aligned unsigned APK
        val patchDesc = if (config.hideFromLauncher) {
            "Re-identifying package ID & hiding from home screen launcher..."
        } else {
            "Re-identifying AndroidManifest.xml package ID..."
        }
        onProgress(CloneBuildProgress(3, 5, patchDesc))

        val unsignedClonedApk = File(vaultDir, "cloned_unsigned.apk")
        val finalClonedApk = File(vaultDir, "cloned.apk")
        var manifestPatched = false
        var launcherHidden = false
        var cloneCertSha = ""

        runCatching {
            val outcome = repackageApkWithRenamedManifest(
                sourceApk = snapshotApk,
                outputUnsignedApk = unsignedClonedApk,
                originalPackage = config.inspectedApk.packageName,
                clonedPackage = config.clonedPackageName,
                hideFromLauncher = config.hideFromLauncher
            )
            manifestPatched = outcome.first
            launcherHidden = outcome.second

            // Step 4: Sign cloned APK with APK Signature Scheme v2
            onProgress(CloneBuildProgress(4, 5, "Signing independent APK with v2 sandbox key..."))
            val identity = ApkSignerV2.getOrCreateIdentity(keystoreDir)
            cloneCertSha = ApkSignerV2.signApkV2(unsignedClonedApk, finalClonedApk, identity)
            unsignedClonedApk.delete()
        }.onFailure {
            unsignedClonedApk.delete()
            if (!finalClonedApk.exists()) {
                snapshotApk.copyTo(finalClonedApk, overwrite = true)
            }
            cloneCertSha = config.inspectedApk.signingSha256
        }

        // Step 5: Persist metadata
        onProgress(CloneBuildProgress(5, 5, "Finalizing sandbox registration..."))
        ClonedAppEntity(
            cloneUuid = cloneUuid,
            displayName = config.inspectedApk.appName,
            cloneLabel = config.cloneLabel.ifBlank { "${config.inspectedApk.appName} (Sandbox)" },
            originalPackageName = config.inspectedApk.packageName,
            clonedPackageName = config.clonedPackageName,
            versionName = config.inspectedApk.versionName,
            versionCode = config.inspectedApk.versionCode,
            minSdk = config.inspectedApk.minSdk,
            targetSdk = config.inspectedApk.targetSdk,
            apkSizeBytes = snapshotApk.length(),
            originalSnapshotPath = snapshotApk.absolutePath,
            clonedApkPath = finalClonedApk.absolutePath,
            isolatedDataDir = dataDir.absolutePath,
            signingSha256 = config.inspectedApk.signingSha256,
            cloneSigningSha256 = cloneCertSha,
            dexCount = config.inspectedApk.dexCount,
            nativeAbis = config.inspectedApk.nativeAbis.joinToString(", "),
            permissionsList = config.inspectedApk.permissions.joinToString("\n"),
            isolationMode = config.isolationMode,
            isolateStorage = config.isolateStorage,
            isolateDeviceIds = config.isolateDeviceIds,
            blockTrackers = config.blockTrackers,
            networkMode = config.networkMode,
            hideFromLauncher = config.hideFromLauncher && launcherHidden,
            mainActivityClass = config.inspectedApk.mainActivityClass,
            manifestPatched = manifestPatched,
            notes = buildString {
                if (manifestPatched) {
                    append("Package re-identified to ${config.clonedPackageName}")
                } else {
                    append("Archived full APK snapshot inside isolated VaultBox sandbox")
                }
                if (config.hideFromLauncher && launcherHidden) {
                    append(" • Hidden from home screen launcher (Vault-only launch)")
                }
            }
        )
    }

    private fun repackageApkWithRenamedManifest(
        sourceApk: File,
        outputUnsignedApk: File,
        originalPackage: String,
        clonedPackage: String,
        hideFromLauncher: Boolean
    ): Pair<Boolean, Boolean> {
        var didPatchManifest = false
        var didHideLauncher = false

        ZipFile(sourceApk).use { zipIn ->
            val countingOut = CountingOutputStream(FileOutputStream(outputUnsignedApk))
            ZipOutputStream(countingOut).use { zipOut ->
                val entries = zipIn.entries()
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    val name = entry.name
                    if (name.startsWith("META-INF/") &&
                        (name.endsWith(".SF") || name.endsWith(".RSA") || name.endsWith(".DSA") ||
                            name.endsWith(".EC") || name == "META-INF/MANIFEST.MF")
                    ) {
                        continue
                    }

                    val rawBytes = zipIn.getInputStream(entry).use { it.readBytes() }
                    val outBytes = if (name == "AndroidManifest.xml") {
                        val result = AxmlPackagePatcher.patchManifestPackage(
                            axmlBytes = rawBytes,
                            originalPackage = originalPackage,
                            clonedPackage = clonedPackage,
                            hideFromLauncher = hideFromLauncher
                        )
                        didPatchManifest = result.stringsReplacedCount > 0 || originalPackage == clonedPackage
                        didHideLauncher = result.launcherHidden
                        result.patchedBytes
                    } else {
                        rawBytes
                    }

                    val outEntry = ZipEntry(name)
                    val shouldStore = name == "resources.arsc" ||
                        (name.endsWith(".so") && entry.method == ZipEntry.STORED)
                    if (shouldStore) {
                        outEntry.method = ZipEntry.STORED
                        outEntry.size = outBytes.size.toLong()
                        outEntry.compressedSize = outBytes.size.toLong()
                        val crc = CRC32().apply { update(outBytes) }
                        outEntry.crc = crc.value

                        // Ensure 4-byte zipalign data offset (4096-byte page alignment for .so on Android 15/16 if needed, or 4-byte for resources.arsc)
                        zipOut.flush()
                        val alignTo = if (name.endsWith(".so")) 4096L else 4L
                        val nameLen = name.toByteArray(StandardCharsets.UTF_8).size
                        val headerBase = countingOut.bytesWritten + 30L + nameLen
                        val remainder = (headerBase % alignTo).toInt()
                        if (remainder != 0) {
                            val padBytes = (alignTo - remainder).toInt()
                            outEntry.extra = ByteArray(padBytes)
                        }
                    } else {
                        outEntry.method = ZipEntry.DEFLATED
                    }

                    zipOut.putNextEntry(outEntry)
                    zipOut.write(outBytes)
                    zipOut.closeEntry()
                }
            }
        }
        return didPatchManifest to didHideLauncher
    }

    companion object {
        fun generateClonedPackageName(originalPackage: String, suffixTag: String): String {
            val cleanOriginal = originalPackage
                .lowercase()
                .replace(Regex("[^a-z0-9._]"), "")
                .trim('.')
            val cleanTag = suffixTag
                .lowercase()
                .replace(Regex("[^a-z0-9]"), "")
                .ifBlank { "c1" }
                .take(8)
            val tail = cleanOriginal.substringAfterLast('.').ifBlank { "app" }
            return "com.vaultbox.$cleanTag.$tail"
        }

        fun directorySizeBytes(dir: File): Long {
            if (!dir.exists()) return 0L
            return dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
        }
    }
}
