package com.example.engine

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets

/**
 * Parses and patches Android binary XML (AXML) string pools so a cloned APK receives
 * an independent package identifier while preserving binary alignment and XML chunk offsets.
 */
object AxmlPackagePatcher {

    private const val RES_XML_TYPE = 0x0003
    private const val RES_STRING_POOL_TYPE = 0x0001
    private const val UTF8_FLAG = 1 shl 8
    const val SANDBOX_HIDDEN_CATEGORY = "com.vaultbox.category.SANDBOX"
    private const val CATEGORY_LAUNCHER = "android.intent.category.LAUNCHER"
    private const val CATEGORY_LEANBACK_LAUNCHER = "android.intent.category.LEANBACK_LAUNCHER"

    data class PatchResult(
        val patchedBytes: ByteArray,
        val stringsReplacedCount: Int,
        val launcherHidden: Boolean = false
    )

    fun patchManifestPackage(
        axmlBytes: ByteArray,
        originalPackage: String,
        clonedPackage: String,
        hideFromLauncher: Boolean = true
    ): PatchResult {
        if (axmlBytes.size < 36) {
            throw IllegalArgumentException("Invalid AXML header size: ${axmlBytes.size}")
        }

        val buf = ByteBuffer.wrap(axmlBytes).order(ByteOrder.LITTLE_ENDIAN)
        val xmlType = buf.getShort(0).toInt() and 0xFFFF
        val xmlHeaderSize = buf.getShort(2).toInt() and 0xFFFF
        if (xmlType != RES_XML_TYPE) {
            throw IllegalArgumentException("Expected RES_XML_TYPE (0x0003), got 0x${xmlType.toString(16)}")
        }

        val poolOffset = xmlHeaderSize
        val poolType = buf.getShort(poolOffset).toInt() and 0xFFFF
        val poolHeaderSize = buf.getShort(poolOffset + 2).toInt() and 0xFFFF
        val poolSize = buf.getInt(poolOffset + 4)
        if (poolType != RES_STRING_POOL_TYPE) {
            throw IllegalArgumentException("Expected RES_STRING_POOL_TYPE (0x0001), got 0x${poolType.toString(16)}")
        }

        val stringCount = buf.getInt(poolOffset + 8)
        val styleCount = buf.getInt(poolOffset + 12)
        val flags = buf.getInt(poolOffset + 16)
        val stringsStart = buf.getInt(poolOffset + 20)
        val stylesStart = buf.getInt(poolOffset + 24)
        val isUtf8 = (flags and UTF8_FLAG) != 0

        val stringOffsets = IntArray(stringCount) { idx ->
            buf.getInt(poolOffset + poolHeaderSize + idx * 4)
        }
        val styleOffsets = IntArray(styleCount) { idx ->
            buf.getInt(poolOffset + poolHeaderSize + stringCount * 4 + idx * 4)
        }

        val absoluteStringsBase = poolOffset + stringsStart
        val decodedStrings = MutableList(stringCount) { idx ->
            val strStart = absoluteStringsBase + stringOffsets[idx]
            if (isUtf8) readUtf8String(axmlBytes, strStart) else readUtf16String(axmlBytes, strStart)
        }

        var replaced = 0
        var launcherHidden = false
        for (i in decodedStrings.indices) {
            val s = decodedStrings[i]
            when {
                s == originalPackage -> {
                    decodedStrings[i] = clonedPackage
                    replaced++
                }
                s.startsWith("$originalPackage.") -> {
                    decodedStrings[i] = clonedPackage + s.removePrefix(originalPackage)
                    replaced++
                }
                hideFromLauncher && (s == CATEGORY_LAUNCHER || s == CATEGORY_LEANBACK_LAUNCHER) -> {
                    decodedStrings[i] = SANDBOX_HIDDEN_CATEGORY
                    launcherHidden = true
                }
            }
        }

        // Re-encode string data
        val newStringOffsets = IntArray(stringCount)
        val stringDataOut = ByteArrayOutputStream()
        for (i in decodedStrings.indices) {
            newStringOffsets[i] = stringDataOut.size()
            val encoded = if (isUtf8) {
                encodeUtf8String(decodedStrings[i])
            } else {
                encodeUtf16String(decodedStrings[i])
            }
            stringDataOut.write(encoded)
        }
        while (stringDataOut.size() % 4 != 0) {
            stringDataOut.write(0)
        }
        val newStringsData = stringDataOut.toByteArray()

        // Preserve styles bytes verbatim if present
        val oldStylesBytes = if (styleCount > 0 && stylesStart > 0) {
            val absStylesStart = poolOffset + stylesStart
            val absPoolEnd = poolOffset + poolSize
            if (absStylesStart in 0..absPoolEnd) {
                axmlBytes.copyOfRange(absStylesStart, absPoolEnd)
            } else {
                ByteArray(0)
            }
        } else {
            ByteArray(0)
        }

        val newStringsStart = poolHeaderSize + stringCount * 4 + styleCount * 4
        val newStylesStart = if (styleCount > 0 && oldStylesBytes.isNotEmpty()) {
            newStringsStart + newStringsData.size
        } else {
            0
        }
        val newPoolSize = newStringsStart + newStringsData.size + oldStylesBytes.size

        val restStart = poolOffset + poolSize
        val restBytes = axmlBytes.copyOfRange(restStart, axmlBytes.size)
        val newTotalXmlSize = xmlHeaderSize + newPoolSize + restBytes.size

        val out = ByteBuffer.allocate(newTotalXmlSize).order(ByteOrder.LITTLE_ENDIAN)
        // Root XML header
        out.putShort(RES_XML_TYPE.toShort())
        out.putShort(xmlHeaderSize.toShort())
        out.putInt(newTotalXmlSize)
        if (xmlHeaderSize > 8) {
            out.put(axmlBytes, 8, xmlHeaderSize - 8)
        }

        // String pool header
        out.putShort(RES_STRING_POOL_TYPE.toShort())
        out.putShort(poolHeaderSize.toShort())
        out.putInt(newPoolSize)
        out.putInt(stringCount)
        out.putInt(styleCount)
        out.putInt(flags)
        out.putInt(newStringsStart)
        out.putInt(newStylesStart)
        if (poolHeaderSize > 28) {
            out.put(axmlBytes, poolOffset + 28, poolHeaderSize - 28)
        }

        // String & style offset tables
        newStringOffsets.forEach { out.putInt(it) }
        styleOffsets.forEach { out.putInt(it) }

        // String & style payloads
        out.put(newStringsData)
        out.put(oldStylesBytes)

        // Remaining XML chunks verbatim
        out.put(restBytes)

        return PatchResult(
            patchedBytes = out.array(),
            stringsReplacedCount = replaced,
            launcherHidden = launcherHidden
        )
    }

    private fun readUtf8String(bytes: ByteArray, offset: Int): String {
        var pos = offset
        // Skip UTF-16 length (1 or 2 bytes)
        val b0 = bytes[pos++].toInt() and 0xFF
        if ((b0 and 0x80) != 0) pos++
        // Read UTF-8 byte length (1 or 2 bytes)
        val l0 = bytes[pos++].toInt() and 0xFF
        val byteLen = if ((l0 and 0x80) != 0) {
            val l1 = bytes[pos++].toInt() and 0xFF
            ((l0 and 0x7F) shl 8) or l1
        } else {
            l0
        }
        return String(bytes, pos, byteLen, StandardCharsets.UTF_8)
    }

    private fun readUtf16String(bytes: ByteArray, offset: Int): String {
        var pos = offset
        val w0 = ((bytes[pos + 1].toInt() and 0xFF) shl 8) or (bytes[pos].toInt() and 0xFF)
        pos += 2
        val charLen = if ((w0 and 0x8000) != 0) {
            val w1 = ((bytes[pos + 1].toInt() and 0xFF) shl 8) or (bytes[pos].toInt() and 0xFF)
            pos += 2
            ((w0 and 0x7FFF) shl 16) or w1
        } else {
            w0
        }
        return String(bytes, pos, charLen * 2, StandardCharsets.UTF_16LE)
    }

    private fun encodeUtf8String(value: String): ByteArray {
        val utf8Bytes = value.toByteArray(StandardCharsets.UTF_8)
        val utf16Len = value.length
        val out = ByteArrayOutputStream()
        writeUtf8Length(out, utf16Len)
        writeUtf8Length(out, utf8Bytes.size)
        out.write(utf8Bytes)
        out.write(0)
        return out.toByteArray()
    }

    private fun encodeUtf16String(value: String): ByteArray {
        val utf16Bytes = value.toByteArray(StandardCharsets.UTF_16LE)
        val utf16Len = value.length
        val out = ByteArrayOutputStream()
        if (utf16Len > 0x7FFF) {
            val high = (utf16Len ushr 16) or 0x8000
            val low = utf16Len and 0xFFFF
            out.write(high and 0xFF)
            out.write((high ushr 8) and 0xFF)
            out.write(low and 0xFF)
            out.write((low ushr 8) and 0xFF)
        } else {
            out.write(utf16Len and 0xFF)
            out.write((utf16Len ushr 8) and 0xFF)
        }
        out.write(utf16Bytes)
        out.write(0)
        out.write(0)
        return out.toByteArray()
    }

    private fun writeUtf8Length(out: ByteArrayOutputStream, len: Int) {
        if (len > 0x7F) {
            out.write(((len ushr 8) and 0x7F) or 0x80)
            out.write(len and 0xFF)
        } else {
            out.write(len and 0x7F)
        }
    }
}
