package com.example.engine

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.RandomAccessFile
import java.math.BigInteger
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.Signature
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date

/**
 * Pure-Kotlin APK Signature Scheme v2 signer with deterministic self-signed X.509 v3
 * certificate generation for standalone cloned APKs.
 */
object ApkSignerV2 {

    private const val EOCD_SIGNATURE = 0x06054b50
    private const val APK_SIG_BLOCK_ID_V2 = 0x7109871a
    private const val SIG_ALG_RSA_PKCS1_SHA256 = 0x0103
    private const val CHUNK_SIZE_BYTES = 1024 * 1024 // 1 MB
    private val APK_SIG_BLOCK_MAGIC = "APK Sig Block 42".toByteArray(StandardCharsets.US_ASCII)

    data class SigningIdentity(
        val privateKey: PrivateKey,
        val publicKeyEncoded: ByteArray,
        val certificateDer: ByteArray,
        val certSha256: String
    )

    fun getOrCreateIdentity(keystoreDir: File): SigningIdentity {
        keystoreDir.mkdirs()
        val keyFile = File(keystoreDir, "vaultbox_clone_key.pk8")
        val certFile = File(keystoreDir, "vaultbox_clone_cert.der")
        val pubFile = File(keystoreDir, "vaultbox_clone_pub.der")

        if (keyFile.exists() && certFile.exists() && pubFile.exists()) {
            val privBytes = keyFile.readBytes()
            val certBytes = certFile.readBytes()
            val pubBytes = pubFile.readBytes()
            val privKey = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(privBytes))
            return SigningIdentity(
                privateKey = privKey,
                publicKeyEncoded = pubBytes,
                certificateDer = certBytes,
                certSha256 = sha256Hex(certBytes)
            )
        }

        val kpg = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }
        val keyPair = kpg.generateKeyPair()
        val certDer = buildSelfSignedX509Cert(keyPair)

        keyFile.writeBytes(keyPair.private.encoded)
        pubFile.writeBytes(keyPair.public.encoded)
        certFile.writeBytes(certDer)

        return SigningIdentity(
            privateKey = keyPair.private,
            publicKeyEncoded = keyPair.public.encoded,
            certificateDer = certDer,
            certSha256 = sha256Hex(certDer)
        )
    }

    fun signApkV2(inputApk: File, outputApk: File, identity: SigningIdentity): String {
        val rawBytes = inputApk.readBytes()
        val eocdOffset = findEocdOffset(rawBytes)
        if (eocdOffset < 0) {
            throw IllegalArgumentException("ZIP EOCD record not found in ${inputApk.name}")
        }

        val eocdBuf = ByteBuffer.wrap(rawBytes, eocdOffset, rawBytes.size - eocdOffset)
            .slice()
            .order(ByteOrder.LITTLE_ENDIAN)
        val cdOffset = eocdBuf.getInt(16).toLong() and 0xFFFFFFFFL
        if (cdOffset <= 0 || cdOffset >= eocdOffset) {
            throw IllegalArgumentException("Invalid ZIP Central Directory offset: $cdOffset")
        }

        val entriesLen = cdOffset.toInt()
        val cdLen = eocdOffset - entriesLen
        val eocdBytes = rawBytes.copyOfRange(eocdOffset, rawBytes.size)

        // Compute APK Signature Scheme v2 Merkle chunk digests
        val chunkDigests = mutableListOf<ByteArray>()
        collectChunkDigests(rawBytes, 0, entriesLen, chunkDigests)
        collectChunkDigests(rawBytes, entriesLen, cdLen, chunkDigests)
        collectChunkDigests(eocdBytes, 0, eocdBytes.size, chunkDigests)

        val topDigestInput = ByteArrayOutputStream().apply {
            write(0x5a)
            write(intToLeBytes(chunkDigests.size))
            chunkDigests.forEach { write(it) }
        }.toByteArray()
        val contentDigest = MessageDigest.getInstance("SHA-256").digest(topDigestInput)

        // Build SignedData: digests, certificates, additionalAttributes
        val digestEntry = lengthPrefixed(
            ByteBuffer.allocate(4 + 4 + contentDigest.size).order(ByteOrder.LITTLE_ENDIAN)
                .putInt(SIG_ALG_RSA_PKCS1_SHA256)
                .putInt(contentDigest.size)
                .put(contentDigest)
                .array()
        )
        val digestsSeq = lengthPrefixed(digestEntry)
        val certsSeq = lengthPrefixed(lengthPrefixed(identity.certificateDer))
        val attrsSeq = lengthPrefixed(ByteArray(0))

        val signedData = ByteArrayOutputStream().apply {
            write(digestsSeq)
            write(certsSeq)
            write(attrsSeq)
        }.toByteArray()

        val sigBytes = Signature.getInstance("SHA256withRSA").run {
            initSign(identity.privateKey)
            update(signedData)
            sign()
        }

        val sigEntry = lengthPrefixed(
            ByteBuffer.allocate(4 + 4 + sigBytes.size).order(ByteOrder.LITTLE_ENDIAN)
                .putInt(SIG_ALG_RSA_PKCS1_SHA256)
                .putInt(sigBytes.size)
                .put(sigBytes)
                .array()
        )

        val signer = ByteArrayOutputStream().apply {
            write(lengthPrefixed(signedData))
            write(lengthPrefixed(sigEntry))
            write(lengthPrefixed(identity.publicKeyEncoded))
        }.toByteArray()

        val signersBlock = lengthPrefixed(lengthPrefixed(signer))

        // Build APK Signing Block with 8-byte pair length + 4-byte ID + value
        val pairBytes = ByteBuffer.allocate(8 + 4 + signersBlock.size).order(ByteOrder.LITTLE_ENDIAN)
            .putLong((4 + signersBlock.size).toLong())
            .putInt(APK_SIG_BLOCK_ID_V2)
            .put(signersBlock)
            .array()

        val sizeOfBlockField = (pairBytes.size + 8 + APK_SIG_BLOCK_MAGIC.size).toLong()
        val signingBlock = ByteBuffer.allocate(8 + sizeOfBlockField.toInt()).order(ByteOrder.LITTLE_ENDIAN)
            .putLong(sizeOfBlockField)
            .put(pairBytes)
            .putLong(sizeOfBlockField)
            .put(APK_SIG_BLOCK_MAGIC)
            .array()

        // Update EOCD central directory offset to point past the signing block
        val patchedEocd = eocdBytes.copyOf()
        val newCdOffset = (cdOffset + signingBlock.size).toInt()
        ByteBuffer.wrap(patchedEocd).order(ByteOrder.LITTLE_ENDIAN).putInt(16, newCdOffset)

        RandomAccessFile(outputApk, "rw").use { raf ->
            raf.setLength(0)
            raf.write(rawBytes, 0, entriesLen)
            raf.write(signingBlock)
            raf.write(rawBytes, entriesLen, cdLen)
            raf.write(patchedEocd)
        }

        return identity.certSha256
    }

    private fun collectChunkDigests(
        data: ByteArray,
        start: Int,
        length: Int,
        outDigests: MutableList<ByteArray>
    ) {
        var offset = start
        val end = start + length
        if (length == 0) {
            val md = MessageDigest.getInstance("SHA-256")
            md.update(0xa5.toByte())
            md.update(intToLeBytes(0))
            outDigests.add(md.digest())
            return
        }
        while (offset < end) {
            val chunkLen = minOf(CHUNK_SIZE_BYTES, end - offset)
            val md = MessageDigest.getInstance("SHA-256")
            md.update(0xa5.toByte())
            md.update(intToLeBytes(chunkLen))
            md.update(data, offset, chunkLen)
            outDigests.add(md.digest())
            offset += chunkLen
        }
    }

    private fun findEocdOffset(data: ByteArray): Int {
        val minOffset = maxOf(0, data.size - 65557)
        for (i in (data.size - 22) downTo minOffset) {
            if (data[i] == 0x50.toByte() &&
                data[i + 1] == 0x4b.toByte() &&
                data[i + 2] == 0x05.toByte() &&
                data[i + 3] == 0x06.toByte()
            ) {
                val commentLen = ((data[i + 21].toInt() and 0xFF) shl 8) or (data[i + 20].toInt() and 0xFF)
                if (i + 22 + commentLen == data.size) {
                    return i
                }
            }
        }
        return -1
    }

    private fun lengthPrefixed(bytes: ByteArray): ByteArray {
        return ByteBuffer.allocate(4 + bytes.size).order(ByteOrder.LITTLE_ENDIAN)
            .putInt(bytes.size)
            .put(bytes)
            .array()
    }

    private fun intToLeBytes(v: Int): ByteArray {
        return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(v).array()
    }

    private fun sha256Hex(bytes: ByteArray): String {
        return MessageDigest.getInstance("SHA-256")
            .digest(bytes)
            .joinToString("") { "%02x".format(it) }
    }

    /**
     * Minimal ASN.1 DER X.509 v3 self-signed certificate builder using standard Java crypto.
     */
    private fun buildSelfSignedX509Cert(keyPair: KeyPair): ByteArray {
        val serialBytes = BigInteger.valueOf(System.currentTimeMillis()).toByteArray()
        val sigAlgId = derSeq(
            derOid(byteArrayOf(0x2a, 0x86.toByte(), 0x48, 0x86.toByte(), 0xf7.toByte(), 0x0d, 0x01, 0x01, 0x0b)), // sha256WithRSAEncryption
            byteArrayOf(0x05, 0x00) // NULL
        )
        val cnAttr = derSet(
            derSeq(
                derOid(byteArrayOf(0x55, 0x04, 0x03)), // CN
                derUtf8("VaultBox Sandbox")
            )
        )
        val name = derSeq(cnAttr)
        val validity = derSeq(
            derUtcTime(Date(1704067200000L)), // 2024-01-01
            derUtcTime(Date(2524608000000L))  // 2050-01-01
        )
        val version = byteArrayOf(0xa0.toByte(), 0x03, 0x02, 0x01, 0x02) // [0] INTEGER 2 (v3)
        val tbsCert = derSeq(
            version,
            derTag(0x02, serialBytes),
            sigAlgId,
            name,
            validity,
            name,
            keyPair.public.encoded
        )

        val signature = Signature.getInstance("SHA256withRSA").run {
            initSign(keyPair.private)
            update(tbsCert)
            sign()
        }
        val sigBitString = derBitString(signature)
        return derSeq(tbsCert, sigAlgId, sigBitString)
    }

    private fun derSeq(vararg items: ByteArray): ByteArray = derTag(0x30, concat(*items))
    private fun derSet(vararg items: ByteArray): ByteArray = derTag(0x31, concat(*items))
    private fun derOid(oidBytes: ByteArray): ByteArray = derTag(0x06, oidBytes)
    private fun derUtf8(text: String): ByteArray = derTag(0x0C, text.toByteArray(StandardCharsets.UTF_8))
    private fun derBitString(bytes: ByteArray): ByteArray = derTag(0x03, byteArrayOf(0x00) + bytes)

    private fun derUtcTime(date: Date): ByteArray {
        val fmt = java.text.SimpleDateFormat("yyMMddHHmmss'Z'", java.util.Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("UTC")
        }
        return derTag(0x17, fmt.format(date).toByteArray(StandardCharsets.US_ASCII))
    }

    private fun derTag(tag: Int, content: ByteArray): ByteArray {
        val lenBytes = when {
            content.size < 128 -> byteArrayOf(content.size.toByte())
            content.size <= 0xFF -> byteArrayOf(0x81.toByte(), content.size.toByte())
            content.size <= 0xFFFF -> byteArrayOf(
                0x82.toByte(),
                (content.size ushr 8).toByte(),
                content.size.toByte()
            )
            else -> byteArrayOf(
                0x83.toByte(),
                (content.size ushr 16).toByte(),
                (content.size ushr 8).toByte(),
                content.size.toByte()
            )
        }
        return byteArrayOf(tag.toByte()) + lenBytes + content
    }

    private fun concat(vararg arrays: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        arrays.forEach { out.write(it) }
        return out.toByteArray()
    }
}
